import 'package:flutter/material.dart' hide Thumb;
import 'core.dart';
import 'engine.dart';
import 'ui.dart';

/// Always-visible downloads strip (pinned under the content) so you can keep
/// watching while monitoring downloads. Tap the header to collapse / expand.
class MiniDownloads extends StatefulWidget {
  const MiniDownloads({super.key});
  @override
  State<MiniDownloads> createState() => _MiniDownloadsState();
}

class _MiniDownloadsState extends State<MiniDownloads> {
  bool open = true;

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: DM.i,
        builder: (c, _) {
          final all = DM.i.items;
          if (all.isEmpty) return const SizedBox.shrink();
          final busy = all.where((e) => e.status == 'downloading' || e.status == 'queued').toList();
          final fin = all.where((e) => e.status != 'downloading' && e.status != 'queued').take(15).toList();
          final list = [...busy, ...fin];
          double overall = 0;
          final run = busy.where((e) => e.status == 'downloading').toList();
          if (run.isNotEmpty) overall = run.map((e) => e.progress).reduce((a, b) => a + b) / run.length;
          return Container(
            decoration: const BoxDecoration(
              color: kCard,
              border: Border(top: BorderSide(color: Colors.white12)),
            ),
            child: SafeArea(
              top: false,
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                InkWell(
                  onTap: () => setState(() => open = !open),
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(14, 10, 8, 10),
                    child: Row(children: [
                      const Icon(Icons.download_rounded, color: kRed, size: 20),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          '${tr('downloads')}  •  ${busy.length} ${tr('active_n')}',
                          style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13.5),
                        ),
                      ),
                      if (busy.isNotEmpty) Text('${(overall * 100).round()}%', style: const TextStyle(color: Colors.grey, fontSize: 12)),
                      Icon(open ? Icons.keyboard_arrow_down_rounded : Icons.keyboard_arrow_up_rounded),
                    ]),
                  ),
                ),
                if (busy.isNotEmpty && !open)
                  LinearProgressIndicator(value: run.isEmpty ? null : overall, minHeight: 2),
                if (open)
                  ConstrainedBox(
                    constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * .26),
                    child: ListView.builder(
                      shrinkWrap: true,
                      padding: const EdgeInsets.only(bottom: 6),
                      itemCount: list.length,
                      itemBuilder: (_, i) => _row(list[i]),
                    ),
                  ),
              ]),
            ),
          );
        },
      );

  Widget _row(Dl d) {
    String status;
    switch (d.status) {
      case 'downloading':
        if (d.merging) {
          status = tr('merging');
        } else if (d.resolving || (d.total <= 0 && d.got == 0)) {
          status = tr('resolving');
        } else {
          status = '${(d.progress * 100).round()}%'
              '${d.speed > 0 ? '  •  ${fmtBytes(d.speed)}/s' : ''}';
        }
        break;
      case 'queued':
        status = tr('queued');
        break;
      case 'done':
        status = tr('done');
        break;
      case 'error':
        status = tr('failed');
        break;
      default:
        status = tr('canceled');
    }
    final busy = d.status == 'downloading' || d.status == 'queued';
    final indeterminate = d.status == 'downloading' && (d.merging || d.resolving || d.total <= 0);
    return Padding(
      padding: const EdgeInsetsDirectional.fromSTEB(14, 4, 4, 4),
      child: Row(children: [
        Thumb(d.thumb, w: 44, h: 32, radius: 6),
        const SizedBox(width: 10),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(d.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12.5)),
            const SizedBox(height: 3),
            if (d.status == 'downloading')
              LinearProgressIndicator(
                value: indeterminate ? null : d.progress,
                minHeight: 3,
                borderRadius: BorderRadius.circular(3),
              ),
            const SizedBox(height: 2),
            Text(
              status,
              style: TextStyle(
                fontSize: 11,
                color: d.status == 'error' ? Colors.orange : (d.status == 'done' ? Colors.green : Colors.grey),
              ),
            ),
          ]),
        ),
        if (busy)
          IconButton(
            visualDensity: VisualDensity.compact,
            icon: const Icon(Icons.close_rounded, size: 20),
            onPressed: () => DM.i.cancelItem(d),
          )
        else if (d.status == 'error' || d.status == 'canceled')
          IconButton(
            visualDensity: VisualDensity.compact,
            icon: const Icon(Icons.refresh_rounded, size: 20),
            onPressed: () => DM.i.retry(d),
          )
        else
          const SizedBox(width: 8),
      ]),
    );
  }
}
