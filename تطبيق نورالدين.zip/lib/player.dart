import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart' hide Thumb;
import 'package:flutter/services.dart';
import 'package:video_player/video_player.dart';
import 'package:wakelock_plus/wakelock_plus.dart';
import 'core.dart';
import 'ui.dart';

void setFullscreen(bool full) {
  SystemChrome.setPreferredOrientations(
      full ? [DeviceOrientation.landscapeLeft, DeviceOrientation.landscapeRight] : DeviceOrientation.values);
  SystemChrome.setEnabledSystemUIMode(full ? SystemUiMode.immersiveSticky : SystemUiMode.edgeToEdge);
}

/// Video surface with gestures + overlay controls. Used for streaming and local files.
class PlayerSurface extends StatefulWidget {
  final VideoPlayerController vc;
  final String title;
  final bool full;
  final VoidCallback onFull;
  final VoidCallback? onNext, onPrev, onBack, onRetry;
  final String? poster;
  final List<Widget> actions;
  const PlayerSurface({
    super.key,
    required this.vc,
    required this.title,
    required this.full,
    required this.onFull,
    this.onNext,
    this.onPrev,
    this.onBack,
    this.onRetry,
    this.poster,
    this.actions = const [],
  });
  @override
  State<PlayerSurface> createState() => _PlayerSurfaceState();
}

class _PlayerSurfaceState extends State<PlayerSurface> {
  bool show = true;
  Timer? hide;
  Offset tap = Offset.zero;
  String? flash;
  double? drag; // seconds while the user drags the bar

  @override
  void initState() {
    super.initState();
    poke();
  }

  @override
  void dispose() {
    hide?.cancel();
    super.dispose();
  }

  void poke() {
    hide?.cancel();
    if (!show) setState(() => show = true);
    hide = Timer(const Duration(seconds: 3), () {
      if (mounted && widget.vc.value.isPlaying) setState(() => show = false);
    });
  }

  void say(String t) {
    setState(() => flash = t);
    Future.delayed(const Duration(milliseconds: 700), () {
      if (mounted) setState(() => flash = null);
    });
  }

  void seek(int s) {
    final v = widget.vc.value;
    var t = v.position + Duration(seconds: s);
    if (t < Duration.zero) t = Duration.zero;
    if (t > v.duration) t = v.duration;
    widget.vc.seekTo(t);
    say(s > 0 ? '+${s}s' : '${s}s');
  }

  @override
  Widget build(BuildContext context) {
    final vc = widget.vc;
    return Container(
      color: Colors.black,
      child: LayoutBuilder(
        builder: (context, box) => GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: () {
            if (show) {
              setState(() => show = false);
            } else {
              poke();
            }
          },
          onDoubleTapDown: (d) => tap = d.localPosition,
          onDoubleTap: () => seek(tap.dx < box.maxWidth / 2 ? -10 : 10),
          child: ValueListenableBuilder<VideoPlayerValue>(
            valueListenable: vc,
            builder: (_, v, __) {
              final audioOnly = v.isInitialized && v.size.width == 0;
              Widget centre;
              if (v.hasError) {
                centre = Column(mainAxisSize: MainAxisSize.min, children: [
                  const Icon(Icons.error_outline_rounded, color: Colors.white54, size: 44),
                  const SizedBox(height: 6),
                  Text(tr('play_failed'), style: const TextStyle(color: Colors.white70)),
                  if (widget.onRetry != null)
                    TextButton(onPressed: widget.onRetry, child: Text(tr('retry'))),
                ]);
              } else if (!v.isInitialized) {
                centre = const CircularProgressIndicator();
              } else if (audioOnly) {
                centre = const Icon(Icons.music_note_rounded, size: 96, color: kRed);
              } else {
                centre = AspectRatio(
                  aspectRatio: v.aspectRatio == 0 ? 1.78 : v.aspectRatio,
                  child: VideoPlayer(vc),
                );
              }
              return Stack(fit: StackFit.expand, children: [
                if (audioOnly && widget.poster != null)
                  Positioned.fill(child: Opacity(opacity: .3, child: Thumb(widget.poster))),
                Center(child: centre),
                if (v.isBuffering && v.isInitialized) const Center(child: CircularProgressIndicator()),
                if (flash != null)
                  Center(
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                      decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.circular(20)),
                      child: Text(flash!, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                    ),
                  ),
                AnimatedOpacity(
                  opacity: show ? 1 : 0,
                  duration: const Duration(milliseconds: 200),
                  child: IgnorePointer(ignoring: !show, child: _controls(v)),
                ),
              ]);
            },
          ),
        ),
      ),
    );
  }

  /// Seek bar. It follows the app direction, so in Arabic it fills from right to left.
  Widget _seekBar(VideoPlayerValue v) {
    final total = v.duration.inMilliseconds.toDouble();
    final pos = (drag ?? v.position.inMilliseconds.toDouble()).clamp(0.0, total <= 0 ? 1.0 : total).toDouble();
    var buf = 0.0;
    if (v.buffered.isNotEmpty) buf = v.buffered.last.end.inMilliseconds.toDouble();
    return SliderTheme(
      data: SliderTheme.of(context).copyWith(
        trackHeight: 3.5,
        thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 7),
        overlayShape: const RoundSliderOverlayShape(overlayRadius: 16),
        activeTrackColor: kRed,
        inactiveTrackColor: Colors.white24,
        secondaryActiveTrackColor: Colors.white38,
        thumbColor: kRed,
      ),
      child: Directionality(
        textDirection: TextDirection.rtl,
        child: Slider(
        min: 0,
        max: total <= 0 ? 1 : total,
        value: pos,
        secondaryTrackValue: buf.clamp(0.0, total <= 0 ? 1.0 : total).toDouble(),
        onChangeStart: (_) => hide?.cancel(),
        onChanged: (x) => setState(() => drag = x),
        onChangeEnd: (x) {
          widget.vc.seekTo(Duration(milliseconds: x.round()));
          setState(() => drag = null);
          poke();
        },
        ),
      ),
    );
  }

  Widget _controls(VideoPlayerValue v) {
    final vc = widget.vc;
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [Colors.black87, Colors.transparent, Colors.transparent, Colors.black87],
          stops: [0, .3, .65, 1],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
      ),
      child: Column(children: [
        Row(children: [
          if (widget.onBack != null) IconButton(icon: const Icon(Icons.arrow_back_rounded), onPressed: widget.onBack),
          Expanded(
            child: Text(widget.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 14)),
          ),
          PopupMenuButton<double>(
            tooltip: tr('speed'),
            icon: const Icon(Icons.speed_rounded),
            onSelected: (s) {
              vc.setPlaybackSpeed(s);
              say('${s}x');
            },
            itemBuilder: (_) => [for (final s in [0.5, 0.75, 1.0, 1.25, 1.5, 2.0]) PopupMenuItem(value: s, child: Text('${s}x'))],
          ),
          ...widget.actions,
        ]),
        Expanded(
          child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            IconButton(iconSize: 34, icon: const Icon(Icons.skip_previous_rounded), onPressed: widget.onPrev),
            const SizedBox(width: 6),
            IconButton(iconSize: 36, icon: const Icon(Icons.replay_10_rounded), onPressed: () => seek(-10)),
            const SizedBox(width: 6),
            IconButton.filled(
              iconSize: 44,
              style: IconButton.styleFrom(backgroundColor: kRed),
              icon: Icon(v.isPlaying ? Icons.pause_rounded : Icons.play_arrow_rounded),
              onPressed: () {
                v.isPlaying ? vc.pause() : vc.play();
                poke();
              },
            ),
            const SizedBox(width: 6),
            IconButton(iconSize: 36, icon: const Icon(Icons.forward_10_rounded), onPressed: () => seek(10)),
            const SizedBox(width: 6),
            IconButton(iconSize: 34, icon: const Icon(Icons.skip_next_rounded), onPressed: widget.onNext),
          ]),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 0, 4, 4),
          child: Row(children: [
            Text(dur(v.position), style: const TextStyle(fontSize: 12)),
            const SizedBox(width: 8),
            Expanded(child: _seekBar(v)),
            const SizedBox(width: 8),
            Text(dur(v.duration), style: const TextStyle(fontSize: 12)),
            IconButton(
              icon: Icon(widget.full ? Icons.fullscreen_exit_rounded : Icons.fullscreen_rounded),
              onPressed: widget.onFull,
            ),
          ]),
        ),
      ]),
    );
  }
}

/// Plays a downloaded file.
class PlayerPage extends StatefulWidget {
  final File file;
  const PlayerPage({super.key, required this.file});
  @override
  State<PlayerPage> createState() => _PlayerPageState();
}

class _PlayerPageState extends State<PlayerPage> {
  late final VideoPlayerController vc;
  bool full = false;

  @override
  void initState() {
    super.initState();
    WakelockPlus.enable();
    vc = VideoPlayerController.file(widget.file);
    vc.initialize().then((_) {
      if (mounted) {
        setState(() {});
        vc.play();
      }
    }).catchError((_) {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    WakelockPlus.disable();
    vc.dispose();
    SystemChrome.setPreferredOrientations(DeviceOrientation.values);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => PopScope(
        canPop: !full,
        onPopInvokedWithResult: (didPop, _) {
          if (!didPop && full) {
            setState(() => full = false);
            setFullscreen(false);
          }
        },
        child: Scaffold(
          backgroundColor: Colors.black,
          body: SafeArea(
            child: PlayerSurface(
              vc: vc,
              title: widget.file.path.split('/').last,
              full: full,
              onBack: () => Navigator.maybePop(context),
              onFull: () {
                setState(() => full = !full);
                setFullscreen(full);
              },
            ),
          ),
        ),
      );
}
