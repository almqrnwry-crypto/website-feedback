import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'core.dart';
import 'engine.dart';
import 'watch.dart';

class BrowserPage extends StatefulWidget {
  final String url;
  const BrowserPage({super.key, required this.url});
  @override
  State<BrowserPage> createState() => _BrowserPageState();
}

class _BrowserPageState extends State<BrowserPage> {
  late final WebViewController wc;
  String current = '';
  int prog = 0;

  @override
  void initState() {
    super.initState();
    current = widget.url;
    wc = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(kBg)
      ..setNavigationDelegate(NavigationDelegate(
        // keep app-scheme links (intent://, youtube://) from breaking the page
        onNavigationRequest: (r) =>
            r.url.startsWith('http') || r.url.startsWith('about:') ? NavigationDecision.navigate : NavigationDecision.prevent,
        onUrlChange: (c) {
          if (mounted) setState(() => current = c.url ?? current);
        },
        onProgress: (p) {
          if (mounted) setState(() => prog = p);
        },
      ))
      ..loadRequest(Uri.parse(widget.url));
  }

  bool get isDirect => RegExp(r'\.(mp4|mp3|m4a|webm|mkv)(\?.*)?$').hasMatch(current);

  /// Tries to find a plain video file URL inside the page (works on sites that
  /// expose a normal <video src>; streams/blobs can't be saved this way).
  Future<String?> sniff() async {
    try {
      final r = await wc.runJavaScriptReturningResult(
        "(function(){var v=document.querySelector('video');if(!v)return '';"
        "var s=v.currentSrc||v.src||'';"
        "if(!s){var o=v.querySelector('source');if(o)s=o.src||'';}"
        "return s;})()",
      );
      final s = r.toString().replaceAll('"', '').replaceAll(r'\/', '/').trim();
      if (s.startsWith('http') && !s.contains('.m3u8')) return s;
    } catch (_) {}
    return null;
  }

  Future<void> onDownload() async {
    if (isDirect) {
      DM.i.addDirect(current);
      toast(tr('started'));
    } else if (isVideoUrl(current)) {
      // straight to the quality sheet - no need to open the player first
      showDownloadSheet(context, url: current);
    } else if (isPlaylistUrl(current)) {
      openLink(current);
    } else {
      final s = await sniff();
      if (s != null) {
        DM.i.addDirect(s);
        toast(tr('started'));
      } else {
        toast(tr('no_video_found'));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) async {
        if (didPop) return;
        if (await wc.canGoBack()) {
          wc.goBack();
        } else if (context.mounted) {
          Navigator.pop(context);
        }
      },
      child: Scaffold(
        appBar: AppBar(
          title: Text(Uri.tryParse(current)?.host ?? '', style: const TextStyle(fontSize: 14)),
          actions: [
            if (isVideoUrl(current))
              IconButton(
                tooltip: tr('watch'),
                icon: const Icon(Icons.play_circle_rounded),
                onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => WatchPage(url: current))),
              ),
            IconButton(icon: const Icon(Icons.refresh_rounded), onPressed: wc.reload),
          ],
          bottom: PreferredSize(
            preferredSize: const Size.fromHeight(2),
            child: prog < 100 ? LinearProgressIndicator(value: prog / 100, minHeight: 2) : const SizedBox(height: 2),
          ),
        ),
        body: WebViewWidget(controller: wc),
        floatingActionButton: FloatingActionButton.extended(
          backgroundColor: kRed,
          foregroundColor: Colors.white,
          onPressed: onDownload,
          icon: const Icon(Icons.download_rounded),
          label: Text(tr('download')),
        ),
      ),
    );
  }
}
