import 'dart:async';
import 'package:flutter/material.dart' hide Thumb;
import 'package:flutter/services.dart';
import 'package:youtube_explode_dart/youtube_explode_dart.dart';
import 'browser.dart';
import 'collection.dart';
import 'core.dart';
import 'engine.dart';
import 'settings.dart';
import 'ui.dart';
import 'watch.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final ctrl = TextEditingController();
  final focus = FocusNode();
  final scroll = ScrollController();
  List<Object> results = [];
  List<String> sugg = [];
  bool loading = false, searched = false, more = false, failed = false;
  String filter = 'all';
  String lastQ = '';
  int token = 0;
  dynamic vsl; // current VideoSearchList (for paging)
  Timer? deb;

  @override
  void initState() {
    super.initState();
    focus.addListener(() => setState(() {}));
    scroll.addListener(() {
      if (scroll.hasClients && scroll.position.pixels > scroll.position.maxScrollExtent - 500) loadMore();
    });
  }

  @override
  void dispose() {
    deb?.cancel();
    ctrl.dispose();
    focus.dispose();
    scroll.dispose();
    super.dispose();
  }

  Future<List<Object>> content(String q, dynamic f, int n) async {
    try {
      final l = await YT.yt.search.searchContent(q, filter: f);
      return l.take(n).cast<Object>().toList();
    } catch (_) {
      return <Object>[];
    }
  }

  List<Object> compose(List<Video> v, List<Object> pl, List<Object> ch) {
    final out = <Object>[...ch];
    var pi = 0;
    for (var i = 0; i < v.length; i++) {
      out.add(v[i]);
      if ((i == 3 || i == 9 || i == 15) && pi < pl.length) out.add(pl[pi++]);
    }
    out.addAll(pl.skip(pi));
    return out;
  }

  Future<void> go([String? query]) async {
    final q = (query ?? ctrl.text).trim();
    if (q.isEmpty) return;
    ctrl.text = q;
    ctrl.selection = TextSelection.collapsed(offset: q.length);
    focus.unfocus();
    if (q.startsWith('http')) {
      openLink(q, ask: true);
      return;
    }
    Prefs.addHistory(q);
    lastQ = q;
    final my = ++token;
    setState(() {
      loading = true;
      searched = true;
      failed = false;
      results = [];
      sugg = [];
      vsl = null;
    });
    try {
      if (filter == 'playlist' || filter == 'channel') {
        final out = await content(q, filter == 'playlist' ? TypeFilters.playlist : TypeFilters.channel, 30);
        if (mounted && my == token) setState(() => results = out);
      } else {
        final all = filter == 'all';
        final fv = YT.yt.search.search(q);
        final fp = all ? content(q, TypeFilters.playlist, 3) : Future.value(<Object>[]);
        final fc = all ? content(q, TypeFilters.channel, 1) : Future.value(<Object>[]);
        final v = await fv;
        if (!mounted || my != token) return;
        vsl = v;
        final vl = <Video>[for (var i = 0; i < v.length; i++) v[i]];
        // videos appear immediately; playlists/channels are merged in when ready
        setState(() {
          results = compose(vl, <Object>[], <Object>[]);
          loading = false;
        });
        final pl = await fp;
        final ch = await fc;
        if (mounted && my == token) {
          setState(() => results = compose(results.whereType<Video>().toList(), pl, ch));
        }
      }
    } catch (_) {
      if (mounted && my == token) setState(() => failed = true);
    }
    if (mounted && my == token) setState(() => loading = false);
  }

  Future<void> loadMore() async {
    if (more || loading || vsl == null) return;
    more = true;
    try {
      final n = await vsl.nextPage();
      if (n != null && mounted) {
        final seen = results.whereType<Video>().map((e) => e.id.value).toSet();
        final fresh = <Object>[for (final x in n) if (x is Video && !seen.contains(x.id.value)) x];
        vsl = fresh.isEmpty ? null : n;
        setState(() => results.addAll(fresh));
      } else {
        vsl = null;
      }
    } catch (_) {
      vsl = null;
    }
    more = false;
  }

  void onChanged(String t) {
    setState(() {});
    deb?.cancel();
    final s = t.trim();
    if (s.length < 2 || s.startsWith('http')) {
      if (sugg.isNotEmpty) setState(() => sugg = []);
      return;
    }
    deb = Timer(const Duration(milliseconds: 280), () async {
      try {
        final l = await YT.yt.search.getQuerySuggestions(s);
        if (mounted && ctrl.text.trim() == s) setState(() => sugg = l.take(8).toList());
      } catch (_) {}
    });
  }

  Future<void> paste() async {
    final t = (await Clipboard.getData('text/plain'))?.text;
    if (t != null && t.trim().isNotEmpty) go(t.trim());
  }

  void clear() => setState(() {
        ctrl.clear();
        searched = false;
        results = [];
        sugg = [];
        failed = false;
        token++;
      });

  Widget item(Object o) {
    if (o is Video) return VideoCard(v: o);
    if (o is SearchPlaylist) {
      final n = (o as dynamic).videoCount;
      return CollectionCard(
        title: (o as dynamic).title as String,
        thumb: thumbOf(o),
        sub: '${n ?? ''} ${tr('videos_n')}',
        tag: tr('playlist'),
        onTap: () {
          final id = (o as dynamic).id.value as String;
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => CollectionPage(
                title: (o as dynamic).title as String,
                thumb: thumbOf(o),
                loader: () => YT.yt.playlists.getVideos(id),
              ),
            ),
          );
        },
      );
    }
    if (o is SearchChannel) {
      String name = '';
      try {
        name = (o as dynamic).name as String;
      } catch (_) {}
      return CollectionCard(
        title: name,
        thumb: thumbOf(o),
        sub: tr('channel'),
        tag: tr('channel'),
        round: true,
        onTap: () {
          final id = (o as dynamic).id.value as String;
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => CollectionPage(
                title: name,
                thumb: thumbOf(o),
                channel: true,
                loader: () => YT.yt.channels.getUploads(id),
              ),
            ),
          );
        },
      );
    }
    return const SizedBox.shrink();
  }

  @override
  Widget build(BuildContext context) {
    final hist = Prefs.history;
    final showSugg = focus.hasFocus && (sugg.isNotEmpty || (ctrl.text.isEmpty && hist.isNotEmpty));
    return Column(children: [
      Container(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 10),
        decoration: const BoxDecoration(
          gradient: LinearGradient(colors: [Color(0xFF9E0016), kBg], begin: Alignment.topCenter, end: Alignment.bottomCenter),
        ),
        child: Column(children: [
          Row(children: [
            Container(
              width: 38,
              height: 38,
              decoration: BoxDecoration(gradient: kGrad, borderRadius: BorderRadius.circular(12)),
              child: const Icon(Icons.bolt_rounded, size: 24, color: Colors.white),
            ),
            const SizedBox(width: 10),
            const Expanded(child: Text('Nooruddin Top', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w800))),
            IconButton(
              icon: const Icon(Icons.settings_rounded),
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SettingsPage())),
            ),
          ]),
          const SizedBox(height: 10),
          TextField(
            controller: ctrl,
            focusNode: focus,
            textInputAction: TextInputAction.search,
            onSubmitted: (_) => go(),
            onChanged: onChanged,
            decoration: InputDecoration(
              filled: true,
              fillColor: kCard,
              hintText: tr('search_hint'),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(30), borderSide: BorderSide.none),
              prefixIcon: IconButton(icon: const Icon(Icons.search_rounded), onPressed: go),
              suffixIcon: ctrl.text.isEmpty
                  ? IconButton(icon: const Icon(Icons.content_paste_rounded), tooltip: tr('paste'), onPressed: paste)
                  : IconButton(icon: const Icon(Icons.close_rounded), onPressed: clear),
            ),
          ),
        ]),
      ),
      if (searched && !showSugg)
        SizedBox(
          height: 46,
          child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 12), children: [
            for (final f in const [('all', 'all'), ('video', 'videos'), ('playlist', 'playlists'), ('channel', 'channels')])
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 6),
                child: ChoiceChip(
                  label: Text(tr(f.$2)),
                  selected: filter == f.$1,
                  selectedColor: kRed,
                  onSelected: (_) {
                    setState(() => filter = f.$1);
                    go(lastQ);
                  },
                ),
              ),
          ]),
        ),
      Expanded(child: showSugg ? suggestions(hist) : body()),
    ]);
  }

  Widget suggestions(List<String> hist) {
    final list = sugg.isNotEmpty ? sugg : hist;
    return ListView(children: [
      if (sugg.isEmpty)
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 8, 0),
          child: Row(children: [
            Expanded(child: Text(tr('recent'), style: const TextStyle(color: Colors.grey))),
            TextButton(
              onPressed: () async {
                await Prefs.clearHistory();
                setState(() {});
              },
              child: Text(tr('clear')),
            ),
          ]),
        ),
      for (final s in list)
        ListTile(
          leading: Icon(sugg.isNotEmpty ? Icons.search_rounded : Icons.history_rounded, color: Colors.grey),
          title: Text(s),
          trailing: IconButton(
            icon: const Icon(Icons.north_west_rounded, size: 18),
            onPressed: () {
              ctrl.text = s;
              ctrl.selection = TextSelection.collapsed(offset: s.length);
              onChanged(s);
            },
          ),
          onTap: () => go(s),
        ),
    ]);
  }

  Widget body() {
    if (loading) {
      return ListView(padding: const EdgeInsets.all(12), children: const [SkeletonCard(), SkeletonCard(), SkeletonCard()]);
    }
    if (searched) {
      if (failed) return ErrorState(tr('search_failed'), () => go(lastQ));
      if (results.isEmpty) return EmptyState(Icons.search_off_rounded, tr('no_results'));
      return ListView.builder(
        controller: scroll,
        padding: const EdgeInsets.all(12),
        itemCount: results.length + 1,
        itemBuilder: (_, i) => i < results.length
            ? item(results[i])
            : (vsl != null ? const Padding(padding: EdgeInsets.all(16), child: Center(child: CircularProgressIndicator())) : const SizedBox(height: 24)),
      );
    }
    return explore();
  }

  Widget explore() {
    final sites = <(String, String, IconData, Color)>[
      ('YouTube', 'https://m.youtube.com', Icons.play_arrow_rounded, const Color(0xFFFF0000)),
      ('Facebook', 'https://m.facebook.com', Icons.facebook, const Color(0xFF1877F2)),
      ('Instagram', 'https://www.instagram.com', Icons.camera_alt_rounded, const Color(0xFFD62976)),
      ('TikTok', 'https://www.tiktok.com', Icons.music_note_rounded, const Color(0xFF25F4EE)),
      ('Twitter', 'https://mobile.twitter.com', Icons.alternate_email, const Color(0xFF1DA1F2)),
      ('Google', 'https://www.google.com', Icons.search_rounded, const Color(0xFF34A853)),
      ('Vimeo', 'https://vimeo.com', Icons.videocam_rounded, const Color(0xFF1AB7EA)),
      ('Dailymotion', 'https://www.dailymotion.com', Icons.smart_display_rounded, const Color(0xFF0066DC)),
    ];
    const cats = [
      ('cat_music', 'q_music', Icons.music_note_rounded),
      ('cat_quran', 'q_quran', Icons.menu_book_rounded),
      ('cat_news', 'q_news', Icons.newspaper_rounded),
      ('cat_gaming', 'q_gaming', Icons.sports_esports_rounded),
      ('cat_sports', 'q_sports', Icons.sports_soccer_rounded),
      ('cat_movies', 'q_movies', Icons.movie_rounded),
      ('cat_cooking', 'q_cooking', Icons.restaurant_rounded),
      ('cat_learning', 'q_learning', Icons.school_rounded),
    ];
    return ListView(padding: const EdgeInsets.all(16), children: [
      ValueListenableBuilder<int>(
        valueListenable: Prefs.watchedTick,
        builder: (_, __, ___) {
          final w = Prefs.watched;
          if (w.isEmpty) return const SizedBox.shrink();
          return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(tr('watched'), style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
            const SizedBox(height: 10),
            SizedBox(
              height: 148,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                itemCount: w.length,
                separatorBuilder: (_, __) => const SizedBox(width: 10),
                itemBuilder: (_, i) {
                  final id = w[i]['id'] as String;
                  return InkWell(
                    borderRadius: BorderRadius.circular(12),
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => WatchPage(url: 'https://youtu.be/$id')),
                    ),
                    child: SizedBox(
                      width: 150,
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Thumb('https://i.ytimg.com/vi/$id/mqdefault.jpg', w: 150, h: 84, radius: 12),
                        const SizedBox(height: 6),
                        Text('${w[i]['t']}', maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12, height: 1.25)),
                      ]),
                    ),
                  );
                },
              ),
            ),
            const SizedBox(height: 22),
          ]);
        },
      ),
      Text(tr('explore'), style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
      const SizedBox(height: 10),
      Wrap(spacing: 8, runSpacing: 8, children: [
        for (final c in cats)
          ActionChip(
            avatar: Icon(c.$3, size: 18, color: kRed),
            label: Text(tr(c.$1)),
            onPressed: () => go(tr(c.$2)),
          ),
      ]),
      const SizedBox(height: 22),
      Text(tr('sites'), style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
      const SizedBox(height: 10),
      GridView.count(
        crossAxisCount: 4,
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        mainAxisSpacing: 14,
        children: [
          for (final s in sites)
            InkWell(
              borderRadius: BorderRadius.circular(16),
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => BrowserPage(url: s.$2))),
              child: Column(children: [
                CircleAvatar(radius: 28, backgroundColor: s.$4, child: Icon(s.$3, color: Colors.white, size: 30)),
                const SizedBox(height: 6),
                Text(s.$1, style: const TextStyle(fontSize: 12)),
              ]),
            ),
        ],
      ),
    ]);
  }
}

class VideoCard extends StatelessWidget {
  final Video v;
  const VideoCard({super.key, required this.v});
  @override
  Widget build(BuildContext context) => Card(
        color: kCard,
        clipBehavior: Clip.antiAlias,
        margin: const EdgeInsets.only(bottom: 14),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        child: InkWell(
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => WatchPage(url: v.url, known: v))),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Stack(children: [
              Thumb(v.thumbnails.highResUrl, h: 200, w: double.infinity),
              PositionedDirectional(
                bottom: 8,
                start: 8,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(color: Colors.black87, borderRadius: BorderRadius.circular(6)),
                  child: Text(dur(v.duration), style: const TextStyle(fontSize: 11)),
                ),
              ),
              const Positioned.fill(child: Center(child: Icon(Icons.play_circle_fill_rounded, size: 52, color: Colors.white70))),
            ]),
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 10, 6, 10),
              child: Row(children: [
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(v.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 4),
                    Text('${v.author} • ${compact(v.engagement.viewCount)} ${tr('views')}', style: const TextStyle(fontSize: 12, color: Colors.grey)),
                  ]),
                ),
                IconButton(
                  tooltip: tr('audio_only'),
                  icon: const Icon(Icons.music_note_rounded),
                  onPressed: () {
                    DM.i.addVideo(v, 'audio');
                    toast(tr('started'));
                  },
                ),
                IconButton.filled(
                  style: IconButton.styleFrom(backgroundColor: kRed),
                  tooltip: tr('download'),
                  icon: const Icon(Icons.download_rounded),
                  onPressed: () => quickDownload(context, v),
                ),
              ]),
            ),
          ]),
        ),
      );
}

class CollectionCard extends StatelessWidget {
  final String title, sub, tag;
  final String? thumb;
  final bool round;
  final VoidCallback onTap;
  const CollectionCard({super.key, required this.title, required this.sub, required this.tag, required this.onTap, this.thumb, this.round = false});
  @override
  Widget build(BuildContext context) => Card(
        color: kCard,
        margin: const EdgeInsets.only(bottom: 14),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        child: InkWell(
          borderRadius: BorderRadius.circular(18),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Row(children: [
              Thumb(thumb, w: round ? 72 : 120, h: round ? 72 : 68, radius: round ? 36 : 10),
              const SizedBox(width: 12),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(title, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 6),
                  Row(children: [
                    Badge2(tag),
                    const SizedBox(width: 8),
                    Flexible(child: Text(sub, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12, color: Colors.grey))),
                  ]),
                ]),
              ),
              const Icon(Icons.chevron_right_rounded),
            ]),
          ),
        ),
      );
}
