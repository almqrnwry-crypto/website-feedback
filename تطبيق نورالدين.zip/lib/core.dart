import 'dart:convert';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:youtube_explode_dart/youtube_explode_dart.dart';
import 'browser.dart';
import 'collection.dart';
import 'engine.dart';
import 'watch.dart';

final navKey = GlobalKey<NavigatorState>();
const kRed = Color(0xFFFF2D3D);
const kRed2 = Color(0xFFFF6A3D);
const kBg = Color(0xFF0B0B0F);
const kCard = Color(0xFF17171E);
const kCard2 = Color(0xFF22222B);
const kGrad = LinearGradient(colors: [kRed, kRed2], begin: Alignment.topLeft, end: Alignment.bottomRight);
const kSheetShape = RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(26)));

// ---------------------------------------------------------------- i18n
final lang = ValueNotifier<String>('ar');

const _ar = <String, String>{
  'home': 'الرئيسية', 'downloads': 'التحميلات', 'library': 'مكتبتي',
  'search_hint': 'ابحث أو الصق رابط...', 'paste': 'لصق',
  'no_results': 'لا توجد نتائج', 'search_failed': 'تعذر البحث، تحقق من الاتصال',
  'all': 'الكل', 'videos': 'فيديوهات', 'playlists': 'قوائم التشغيل', 'channels': 'القنوات',
  'recent': 'عمليات البحث الأخيرة', 'clear': 'مسح', 'explore': 'استكشف', 'sites': 'المواقع',
  'download': 'تحميل', 'audio_only': 'صوت فقط', 'video': 'فيديو', 'audio': 'صوت',
  'quality': 'الجودة', 'started': 'تمت الإضافة، تابع التحميل من تبويب التحميلات',
  'queued': 'في الانتظار', 'downloading': 'جارٍ التحميل', 'resolving': 'جارٍ التجهيز...',
  'done': 'اكتمل', 'failed': 'فشل', 'canceled': 'أُلغي', 'retry': 'إعادة المحاولة',
  'cancel': 'إلغاء', 'clear_done': 'مسح المكتمل', 'retry_failed': 'إعادة الفاشل',
  'cancel_all': 'إلغاء الكل', 'no_downloads': 'لا توجد تحميلات',
  'library_empty': 'المكتبة فارغة', 'delete': 'حذف',
  'delete_q': 'حذف هذا الملف؟', 'yes': 'نعم', 'no': 'لا', 'settings': 'الإعدادات',
  'language': 'اللغة', 'speed': 'السرعة', 'up_next': 'التالي', 'play_all': 'تشغيل الكل',
  'download_all': 'تحميل الكل', 'added_n': 'تمت إضافة %n إلى التحميلات', 'videos_n': 'فيديو',
  'playlist': 'قائمة تشغيل', 'channel': 'قناة',
  'load_failed': 'تعذر التحميل. تأكد من الرابط والاتصال', 'views': 'مشاهدة',
  'clear_history': 'مسح السجل', 'storage': 'المساحة المستخدمة', 'version': 'الإصدار',
  'description': 'الوصف',
  'disclaimer': 'حمّل فقط المحتوى الذي تملكه أو المسموح لك بحفظه، والتزم بشروط المواقع وقوانين بلدك.',
  'cat_music': 'موسيقى', 'cat_quran': 'القرآن الكريم', 'cat_news': 'أخبار', 'cat_gaming': 'ألعاب',
  'cat_sports': 'رياضة', 'cat_movies': 'أفلام', 'cat_cooking': 'طبخ', 'cat_learning': 'تعليم',
  'q_music': 'أغاني جديدة', 'q_quran': 'تلاوة القرآن الكريم', 'q_news': 'أخبار اليوم',
  'q_gaming': 'العاب', 'q_sports': 'ملخص مباريات', 'q_movies': 'أفلام كاملة',
  'q_cooking': 'وصفات طبخ', 'q_learning': 'تعلم',
  'history_cleared': 'تم مسح السجل', 'search_in_library': 'ابحث في المكتبة',
  'watch': 'مشاهدة', 'pick_quality': 'اختر الجودة', 'best': 'أفضل جودة', 'ask': 'اسألني كل مرة',
  'default_dl': 'جودة التحميل الافتراضية', 'stream_q': 'جودة المشاهدة',
  'sq_auto': 'تلقائي (حسب الشبكة)', 'sq_low': 'توفير البيانات', 'sq_high': 'أعلى جودة (HD)',
  'sq_hint': 'التلقائي يبدأ بجودة أقل على بيانات الجوال لتسريع التشغيل',
  'parallel': 'عدد التحميلات المتزامنة', 'gallery': 'حفظ نسخة من الفيديو في المعرض',
  'slow_net': 'الاتصال بطيء؟', 'lower_q': 'خفض الجودة', 'dl_instead': 'حمّله وشاهده لاحقاً',
  'select': 'تحديد', 'select_all': 'تحديد الكل', 'selected_n': '%n محدد',
  'download_sel': 'تحميل المحدد', 'fetching': 'جارٍ جلب كل مقاطع القائمة...',
  'share': 'مشاركة', 'watched': 'شاهدتها مؤخراً', 'play_failed': 'تعذر تشغيل الفيديو',
  'no_video_found': 'لم أجد فيديو قابلاً للتحميل في هذه الصفحة. شغّل الفيديو أولاً ثم اضغط تحميل.',
  'sort_new': 'الأحدث', 'sort_name': 'الاسم', 'sort_size': 'الحجم', 'active': 'جارية',
  'merging': 'جارٍ دمج الصوت والصورة...', 'skipping': 'تعذر تشغيل هذا المقطع، سأنتقل للتالي...',
  'hd_merge': 'HD • يُدمج بعد التحميل', 'mp3_note': 'تحويل إلى MP3', 'active_n': 'نشط', 'no_dl_yet': 'لا توجد تحميلات',
  'parallel_hint': 'كلما زاد العدد زادت السرعة واستهلاك الشبكة', 'next': 'التالي', 'audio_q': 'جودة الصوت', 'video_q': 'جودة الفيديو',
  'finished': 'مكتملة', 'files_n': 'ملف', 'left': 'متبقي', 'general': 'عام',
  'downloads_sec': 'التحميل', 'about': 'حول التطبيق', 'queued_toast': 'أُضيف إلى الطابور',
};

const _en = <String, String>{
  'home': 'Home', 'downloads': 'Downloads', 'library': 'Library',
  'search_hint': 'Search or paste a link...', 'paste': 'Paste',
  'no_results': 'No results', 'search_failed': 'Search failed, check your connection',
  'all': 'All', 'videos': 'Videos', 'playlists': 'Playlists', 'channels': 'Channels',
  'recent': 'Recent searches', 'clear': 'Clear', 'explore': 'Explore', 'sites': 'Sites',
  'download': 'Download', 'audio_only': 'Audio only', 'video': 'Video', 'audio': 'Audio',
  'quality': 'Quality', 'started': 'Added — track it in Downloads',
  'queued': 'Queued', 'downloading': 'Downloading', 'resolving': 'Preparing...',
  'done': 'Done', 'failed': 'Failed', 'canceled': 'Canceled', 'retry': 'Retry',
  'cancel': 'Cancel', 'clear_done': 'Clear finished', 'retry_failed': 'Retry failed',
  'cancel_all': 'Cancel all', 'no_downloads': 'No downloads yet',
  'library_empty': 'Your library is empty', 'delete': 'Delete',
  'delete_q': 'Delete this file?', 'yes': 'Yes', 'no': 'No', 'settings': 'Settings',
  'language': 'Language', 'speed': 'Speed', 'up_next': 'Up next', 'play_all': 'Play all',
  'download_all': 'Download all', 'added_n': '%n added to downloads', 'videos_n': 'videos',
  'playlist': 'Playlist', 'channel': 'Channel',
  'load_failed': "Couldn't load. Check the link and your connection", 'views': 'views',
  'clear_history': 'Clear history', 'storage': 'Storage used', 'version': 'Version',
  'description': 'Description',
  'disclaimer': "Only download content you own or have permission to save, and respect each site's terms and your local laws.",
  'cat_music': 'Music', 'cat_quran': 'Quran', 'cat_news': 'News', 'cat_gaming': 'Gaming',
  'cat_sports': 'Sports', 'cat_movies': 'Movies', 'cat_cooking': 'Cooking', 'cat_learning': 'Learning',
  'q_music': 'new songs', 'q_quran': 'quran recitation', 'q_news': 'news today',
  'q_gaming': 'gaming', 'q_sports': 'match highlights', 'q_movies': 'full movies',
  'q_cooking': 'cooking recipes', 'q_learning': 'learn',
  'history_cleared': 'History cleared', 'search_in_library': 'Search library',
  'watch': 'Watch', 'pick_quality': 'Choose quality', 'best': 'Best quality', 'ask': 'Ask every time',
  'default_dl': 'Default download quality', 'stream_q': 'Streaming quality',
  'sq_auto': 'Auto (by network)', 'sq_low': 'Data saver', 'sq_high': 'Highest (HD)',
  'sq_hint': 'Auto starts at a lower quality on mobile data for faster playback',
  'parallel': 'Simultaneous downloads', 'gallery': 'Save a copy of videos to gallery',
  'slow_net': 'Slow connection?', 'lower_q': 'Lower quality', 'dl_instead': 'Download and watch later',
  'select': 'Select', 'select_all': 'Select all', 'selected_n': '%n selected',
  'download_sel': 'Download selected', 'fetching': 'Fetching the whole list...',
  'share': 'Share', 'watched': 'Recently watched', 'play_failed': "Couldn't play this video",
  'no_video_found': 'No downloadable video found on this page. Play the video first, then tap Download.',
  'sort_new': 'Newest', 'sort_name': 'Name', 'sort_size': 'Size', 'active': 'Active',
  'merging': 'Merging audio and video...', 'skipping': "Can't play this clip, skipping to the next...",
  'hd_merge': 'HD • merged after download', 'mp3_note': 'Convert to MP3', 'active_n': 'active', 'no_dl_yet': 'No downloads',
  'parallel_hint': 'More = faster, but uses more network', 'next': 'Next', 'audio_q': 'Audio quality', 'video_q': 'Video quality',
  'finished': 'Finished', 'files_n': 'files', 'left': 'left', 'general': 'General',
  'downloads_sec': 'Downloads', 'about': 'About', 'queued_toast': 'Added to queue',
};

String tr(String k) => (lang.value == 'ar' ? _ar : _en)[k] ?? k;

String prefLabel(String p) {
  if (p == 'best') return tr('best');
  if (p == 'audio') return tr('audio_only');
  if (p == 'ask') return tr('ask');
  if (p == 'mp3') return 'MP3';
  return '${p}p';
}

// ---------------------------------------------------------------- prefs
class Prefs {
  static late SharedPreferences p;
  static final watchedTick = ValueNotifier<int>(0);

  static Future<void> init() async {
    p = await SharedPreferences.getInstance();
    final sys = WidgetsBinding.instance.platformDispatcher.locale.languageCode;
    lang.value = p.getString('lang') ?? (sys == 'ar' ? 'ar' : 'en');
  }

  static Future<void> setLang(String l) async {
    lang.value = l;
    await p.setString('lang', l);
  }

  // search history
  static List<String> get history => List<String>.from(p.getStringList('history') ?? const []);
  static Future<void> addHistory(String q) async {
    final h = history..remove(q);
    h.insert(0, q);
    await p.setStringList('history', h.take(15).toList());
  }

  static Future<void> clearHistory() async {
    await p.remove('history');
    await p.remove('watched');
    watchedTick.value++;
  }

  // streaming quality: auto | low | high
  static String get sq => p.getString('sq') ?? 'auto';
  static Future<void> setSq(String v) => p.setString('sq', v);

  // default download quality: ask | best | 720 | 480 | 360 | audio
  static String get dq => p.getString('dq') ?? 'ask';
  static Future<void> setDq(String v) => p.setString('dq', v);

  static int get parallel => (p.getInt('par') ?? 2).clamp(1, 10).toInt();
  static Future<void> setParallel(int v) => p.setInt('par', v);

  static bool get gallery => p.getBool('gallery') ?? true;
  static Future<void> setGallery(bool v) => p.setBool('gallery', v);

  // recently watched
  static List<Map<String, dynamic>> get watched {
    try {
      return (p.getStringList('watched') ?? const <String>[])
          .map((e) => Map<String, dynamic>.from(jsonDecode(e) as Map))
          .toList();
    } catch (_) {
      return <Map<String, dynamic>>[];
    }
  }

  static Future<void> addWatched(Video v) async {
    final l = watched..removeWhere((e) => e['id'] == v.id.value);
    l.insert(0, {'id': v.id.value, 't': v.title, 'a': v.author});
    await p.setStringList('watched', l.take(20).map((e) => jsonEncode(e)).toList());
    watchedTick.value++;
  }

  // thumbnails of downloaded files (file name -> url)
  static Map<String, dynamic> thumbs() {
    try {
      return Map<String, dynamic>.from(jsonDecode(p.getString('thumbs') ?? '{}') as Map);
    } catch (_) {
      return <String, dynamic>{};
    }
  }

  static Future<void> setThumb(String file, String url) async {
    final m = thumbs();
    m[file] = url;
    if (m.length > 500) m.remove(m.keys.first);
    await p.setString('thumbs', jsonEncode(m));
  }
}

// ---------------------------------------------------------------- helpers
bool isVideoUrl(String u) => RegExp(r'(youtube\.com/(watch|shorts|live)|youtu\.be/)').hasMatch(u);
bool isPlaylistUrl(String u) => u.contains('youtube.com/playlist');

Future<bool> onMobile() async {
  try {
    final r = await Connectivity().checkConnectivity();
    final wifi = r.contains(ConnectivityResult.wifi) || r.contains(ConnectivityResult.ethernet);
    return !wifi && r.contains(ConnectivityResult.mobile);
  } catch (_) {
    return false;
  }
}

/// Opens any link. [ask] shows a "watch / download" sheet for video links
/// (used for pasted and shared links so download is one tap away).
void openLink(String u, {bool ask = false}) {
  final nav = navKey.currentState;
  final c = navKey.currentContext;
  if (nav == null || c == null) return;
  if (isPlaylistUrl(u)) {
    nav.push(MaterialPageRoute(
      builder: (_) => CollectionPage(title: tr('playlist'), loader: () => YT.yt.playlists.getVideos(u)),
    ));
  } else if (isVideoUrl(u)) {
    if (ask) {
      _linkSheet(c, u);
    } else {
      nav.push(MaterialPageRoute(builder: (_) => WatchPage(url: u)));
    }
  } else {
    nav.push(MaterialPageRoute(builder: (_) => BrowserPage(url: u)));
  }
}

void _linkSheet(BuildContext c, String u) {
  showModalBottomSheet(
    context: c,
    backgroundColor: kCard,
    shape: kSheetShape,
    builder: (s) => SafeArea(
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        const SizedBox(height: 10),
        ListTile(
          leading: const Icon(Icons.play_circle_rounded, color: kRed),
          title: Text(tr('watch')),
          onTap: () {
            Navigator.pop(s);
            navKey.currentState?.push(MaterialPageRoute(builder: (_) => WatchPage(url: u)));
          },
        ),
        ListTile(
          leading: const Icon(Icons.download_rounded, color: kRed),
          title: Text(tr('download')),
          onTap: () {
            Navigator.pop(s);
            showDownloadSheet(c, url: u);
          },
        ),
        ListTile(
          leading: const Icon(Icons.music_note_rounded, color: kRed),
          title: Text(tr('audio_only')),
          onTap: () {
            Navigator.pop(s);
            final id = YT.idOf(u);
            if (id != null) {
              DM.i.addId(id, 'audio');
              toast(tr('started'));
            }
          },
        ),
        const SizedBox(height: 8),
      ]),
    ),
  );
}

String dur(Duration? d) {
  if (d == null) return '';
  String t(int n) => n.toString().padLeft(2, '0');
  return d.inHours > 0
      ? '${d.inHours}:${t(d.inMinutes % 60)}:${t(d.inSeconds % 60)}'
      : '${d.inMinutes}:${t(d.inSeconds % 60)}';
}

String compact(int n) {
  if (n >= 1000000000) return '${(n / 1000000000).toStringAsFixed(1)}B';
  if (n >= 1000000) return '${(n / 1000000).toStringAsFixed(1)}M';
  if (n >= 1000) return '${(n / 1000).toStringAsFixed(1)}K';
  return '$n';
}

String fmtBytes(num b) {
  if (b >= 1073741824) return '${(b / 1073741824).toStringAsFixed(2)} GB';
  if (b >= 1048576) return '${(b / 1048576).toStringAsFixed(1)} MB';
  if (b >= 1024) return '${(b / 1024).toStringAsFixed(0)} KB';
  return '${b.toInt()} B';
}

String fmtEta(int sec) {
  if (sec < 0) return '';
  if (sec < 60) return '${sec}s';
  if (sec < 3600) return '${sec ~/ 60}m ${sec % 60}s';
  return '${sec ~/ 3600}h ${(sec % 3600) ~/ 60}m';
}

String? thumbOf(dynamic x) {
  try {
    final t = x.thumbnails;
    if (t is List && t.isNotEmpty) {
      var u = t.last.url.toString();
      if (u.startsWith('//')) u = 'https:$u';
      return u;
    }
  } catch (_) {}
  return null;
}

void toast(String m) {
  final c = navKey.currentContext;
  if (c == null) return;
  ScaffoldMessenger.of(c)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(m), behavior: SnackBarBehavior.floating));
}
