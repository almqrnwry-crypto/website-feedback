import 'package:flutter/material.dart';
import 'core.dart';
import 'engine.dart';
import 'home.dart';
import 'library.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Prefs.init();
  try {
    await DM.i.init();
  } catch (_) {}
  runApp(const App());
}

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext context) => ValueListenableBuilder<String>(
        valueListenable: lang,
        builder: (_, l, __) => MaterialApp(
          title: 'Nooruddin Top',
          navigatorKey: navKey,
          debugShowCheckedModeBanner: false,
          theme: ThemeData(
            colorSchemeSeed: kRed,
            brightness: Brightness.dark,
            useMaterial3: true,
            scaffoldBackgroundColor: kBg,
            appBarTheme: const AppBarTheme(backgroundColor: kBg, surfaceTintColor: Colors.transparent, elevation: 0),
            navigationBarTheme: NavigationBarThemeData(
              backgroundColor: kCard,
              surfaceTintColor: Colors.transparent,
              indicatorColor: kRed.withValues(alpha: .28),
            ),
            bottomSheetTheme: const BottomSheetThemeData(backgroundColor: kCard, surfaceTintColor: Colors.transparent),
            snackBarTheme: const SnackBarThemeData(behavior: SnackBarBehavior.floating),
            chipTheme: ChipThemeData(
              backgroundColor: kCard,
              side: BorderSide.none,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            ),
          ),
          builder: (c, w) => Directionality(
            textDirection: l == 'ar' ? TextDirection.rtl : TextDirection.ltr,
            child: w!,
          ),
          // keyed by language so every tab re-renders its texts when the language changes
          home: Shell(key: ValueKey(l)),
        ),
      );
}

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int tab = 0;

  @override
  Widget build(BuildContext context) {
    const pages = [HomePage(), DownloadsPage(), LibraryPage()];
    return PopScope(
      canPop: tab == 0,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) setState(() => tab = 0);
      },
      child: Scaffold(
        body: SafeArea(child: IndexedStack(index: tab, children: pages)),
        bottomNavigationBar: ListenableBuilder(
          listenable: DM.i,
          builder: (_, __) => NavigationBar(
            selectedIndex: tab,
            onDestinationSelected: (i) => setState(() => tab = i),
            destinations: [
              NavigationDestination(icon: const Icon(Icons.home_rounded), label: tr('home')),
              NavigationDestination(
                icon: Badge(
                  isLabelVisible: DM.i.active > 0,
                  label: Text('${DM.i.active}'),
                  child: const Icon(Icons.download_rounded),
                ),
                label: tr('downloads'),
              ),
              NavigationDestination(icon: const Icon(Icons.video_library_rounded), label: tr('library')),
            ],
          ),
        ),
      ),
    );
  }
}
