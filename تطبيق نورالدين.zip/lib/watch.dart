import 'dart:async';
import 'package:flutter/material.dart' hide Thumb;
import 'package:share_plus/share_plus.dart';
import 'package:video_player/video_player.dart';
import 'package:wakelock_plus/wakelock_plus.dart';
import 'package:youtube_explode_dart/youtube_explode_dart.dart';
import 'core.dart';
import 'engine.dart';
import 'minidl.dart';
import 'player.dart';
import 'ui.dart';

class _Pair {
  final VideoPlayerController v;
  final VideoPlayerController? a; // separate audio track for HD (video-only) streams
  _Pair(this.v, this.a);
  void dispose() {
    v.dispose();
    a?.dispose();
  }
}

/// Watch a video in-app with any quality (360p ... 4K, and audio-only qualities).
/// HD plays as video + audio kept in sync. Playlists play as a queue with
/// automatic next / skip of unavailable clips. A downloads strip stays pinned below.
class WatchPage extends StatefulWidget {
  final String url;
  final Video? known;
  final List<Video>? queue;
  final int index;
  const WatchPage({super.key, required this.url, this.known, this.queue, this.index = 0});
  @override
  State<WatchPage> createState() => _WatchPageState();
}

class _WatchPageState extends State<WatchPage> {
  late String url;
  late int idx;
  Video? video, hint;
  List<Opt> opts = [];
  int q = 0;
  VideoPlayerController? vc, aux;
  bool loading = true, full = false, ended = false, slow = false, switching = false, seekingAux = false;
  String? error;
  int gen = 0, qgen = 0;
  DateTime? bufSince;

  @override
  void initState() {
    super.initState();
    idx = widget.index;
    hint = widget.queue != null ? widget.queue![idx] : widget.known;
    url = hint?.url ?? widget.url;
    video = hint;
    WakelockPlus.enable();
    load();
  }

  @override
  void dispose() {
    gen++;
    qgen++;
    vc?.removeListener(tick);
    vc?.dispose();
    aux?.dispose();
    WakelockPlus.disable();
    setFullscreen(false);
    super.dispose();
  }

  // ------------------------------------------------------------ sync + health
  void syncAux() {
    final a = aux, c = vc;
    if (a == null || c == null) return;
    final v = c.value, av = a.value;
    if (!av.isInitialized || !v.isInitialized) return;
    final want = v.isPlaying && !v.isBuffering;
    if (want && !av.isPlaying) a.play();
    if (!want && av.isPlaying) a.pause();
    if (av.playbackSpeed != v.playbackSpeed) a.setPlaybackSpeed(v.playbackSpeed);
    final diff = (av.position - v.position).inMilliseconds.abs();
    if (diff > 400 && !seekingAux) {
      seekingAux = true;
      a.seekTo(v.position).whenComplete(() => seekingAux = false);
    }
  }

  void tick() {
    final v = vc?.value;
    if (v == null) return;
    syncAux();
    if (v.isBuffering && v.isInitialized) {
      bufSince ??= DateTime.now();
      if (!slow && mounted && DateTime.now().difference(bufSince!).inSeconds >= 5) setState(() => slow = true);
    } else {
      bufSince = null;
      if (slow && mounted) setState(() => slow = false);
    }
    if (!ended && v.duration > Duration.zero && v.position >= v.duration - const Duration(milliseconds: 500)) {
      ended = true;
      if (widget.queue != null && idx < widget.queue!.length - 1) go(idx + 1);
    }
  }

  void go(int i) {
    if (widget.queue == null || i < 0 || i >= widget.queue!.length) return;
    idx = i;
    hint = widget.queue![i];
    url = hint!.url;
    load();
  }

  // ------------------------------------------------------------ opening
  Future<_Pair> openOpt(Opt o, {bool play = true}) async {
    final v = VideoPlayerController.networkUrl(o.main.url);
    final a = o.audio != null ? VideoPlayerController.networkUrl(o.audio!.url) : null;
    try {
      await Future.wait<void>([v.initialize(), if (a != null) a.initialize()]).timeout(const Duration(seconds: 50));
      if (a != null) await v.setVolume(0);
    } catch (e) {
      v.dispose();
      a?.dispose();
      rethrow;
    }
    v.addListener(tick);
    if (play) {
      v.play();
      a?.play();
    }
    return _Pair(v, a);
  }

  void swap(_Pair? p) {
    final oldV = vc, oldA = aux;
    oldV?.removeListener(tick);
    vc = p?.v;
    aux = p?.a;
    ended = false;
    bufSince = null;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      oldV?.dispose();
      oldA?.dispose();
    });
  }

  Future<void> load() async {
    final my = ++gen;
    setState(() {
      loading = true;
      error = null;
      slow = false;
      video = hint ?? video;
    });
    try {
      final id = YT.idOf(url);
      if (id == null) throw Exception('bad url');
      final meta = await YT.meta(id, known: hint);
      if (my != gen || !mounted) return;
      final list = <Opt>[...videoOpts(meta.manifest), ...audioOpts(meta.manifest)];
      if (list.isEmpty) throw Exception('no streams');
      var qi = pickStart(list, Prefs.sq, await onMobile());
      setState(() {
        video = meta.video;
        opts = list;
      });
      _Pair? p;
      Object? err;
      for (var k = qi; k < list.length && p == null; k++) {
        try {
          p = await openOpt(list[k]);
          qi = k;
        } catch (e) {
          err = e;
          if (my != gen || !mounted) return;
        }
      }
      final _Pair pair = p ?? (throw err ?? Exception('open failed'));
      if (my != gen || !mounted) {
        pair.dispose();
        return;
      }
      setState(() {
        q = qi;
        swap(pair);
        loading = false;
      });
      Prefs.addWatched(meta.video);
      if (meta.video.description.isEmpty) _fillDetails(id, my);
      _prefetchNext();
    } catch (e) {
      if (my == gen && mounted) {
        final more = widget.queue != null && idx < widget.queue!.length - 1;
        setState(() {
          error = more ? tr('skipping') : tr('load_failed');
          loading = false;
        });
        if (more) {
          Future.delayed(const Duration(seconds: 2), () {
            if (mounted && my == gen) go(idx + 1);
          });
        }
      }
    }
  }

  void _prefetchNext() {
    final qa = widget.queue;
    if (qa == null || idx + 1 >= qa.length) return;
    final n = qa[idx + 1];
    YT.meta(n.id.value, known: n).then((_) {}, onError: (_) {});
  }

  Future<void> _fillDetails(String id, int my) async {
    try {
      final v = await YT.yt.videos.get(id);
      if (mounted && my == gen) setState(() => video = v);
    } catch (_) {}
  }

  Future<void> setQuality(int i) async {
    if (i == q || vc == null || i < 0 || i >= opts.length) return;
    final g = gen;
    final my = ++qgen;
    setState(() => switching = true);
    try {
      final p = await openOpt(opts[i], play: false);
      if (g != gen || my != qgen || !mounted || vc == null) {
        p.dispose();
        return;
      }
      final pos = vc!.value.position;
      await p.v.seekTo(pos);
      await p.a?.seekTo(pos);
      p.v.play();
      p.a?.play();
      setState(() {
        q = i;
        slow = false;
        switching = false;
        swap(p);
      });
    } catch (_) {
      if (mounted) setState(() => switching = false);
      toast(tr('load_failed'));
    }
  }

  int? lowerIdx() {
    if (opts.isEmpty) return null;
    if (!opts[q].isAudio) {
      for (var i = q + 1; i < opts.length; i++) {
        if (!opts[i].isAudio) return i;
      }
      for (var i = opts.length - 1; i >= 0; i--) {
        if (opts[i].isAudio) return i; // lightest audio = least data
      }
      return null;
    }
    return q + 1 < opts.length ? q + 1 : null;
  }

  void toggleFull() {
    setState(() => full = !full);
    setFullscreen(full);
  }

  // ------------------------------------------------------------ UI
  List<PopupMenuEntry<int>> qualityMenu() {
    final out = <PopupMenuEntry<int>>[];
    var sep = false;
    for (var i = 0; i < opts.length; i++) {
      final o = opts[i];
      if (o.isAudio && !sep) {
        if (out.isNotEmpty) out.add(const PopupMenuDivider());
        sep = true;
      }
      out.add(CheckedPopupMenuItem<int>(
        value: i,
        checked: i == q,
        child: Text('${o.isAudio ? '♪ ' : ''}${o.label}  •  ${fmtBytes(o.bytes)}'),
      ));
    }
    return out;
  }

  Widget player() {
    if (vc == null || loading || error != null) {
      final thumb = video?.thumbnails.highResUrl;
      return AspectRatio(
        aspectRatio: 16 / 9,
        child: Stack(fit: StackFit.expand, children: [
          Container(color: Colors.black),
          if (thumb != null) Opacity(opacity: .4, child: Thumb(thumb)),
          PositionedDirectional(
            top: 4,
            start: 4,
            child: IconButton(icon: const Icon(Icons.arrow_back_rounded), onPressed: () => Navigator.maybePop(context)),
          ),
          Center(
            child: error != null
                ? Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(mainAxisSize: MainAxisSize.min, children: [
                      Text(error!, textAlign: TextAlign.center),
                      const SizedBox(height: 8),
                      FilledButton(onPressed: load, child: Text(tr('retry'))),
                    ]),
                  )
                : const CircularProgressIndicator(),
          ),
        ]),
      );
    }
    final qa = widget.queue;
    final surface = PlayerSurface(
      vc: vc!,
      title: video?.title ?? '',
      full: full,
      onFull: toggleFull,
      onBack: () => Navigator.maybePop(context),
      onRetry: load,
      poster: video?.thumbnails.highResUrl,
      onPrev: qa != null && idx > 0 ? () => go(idx - 1) : null,
      onNext: qa != null && idx < qa.length - 1 ? () => go(idx + 1) : null,
      actions: [
        if (switching)
          const Padding(
            padding: EdgeInsets.all(12),
            child: SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)),
          ),
        PopupMenuButton<int>(
          tooltip: tr('quality'),
          onSelected: setQuality,
          itemBuilder: (_) => qualityMenu(),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              const Icon(Icons.high_quality_rounded, size: 20),
              const SizedBox(width: 4),
              Text(opts.isNotEmpty && q < opts.length ? opts[q].label : '', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
            ]),
          ),
        ),
      ],
    );
    return full ? surface : AspectRatio(aspectRatio: 16 / 9, child: surface);
  }

  Widget slowBanner() {
    final low = lowerIdx();
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.fromLTRB(14, 4, 6, 4),
      decoration: BoxDecoration(color: kCard, borderRadius: BorderRadius.circular(14)),
      child: Row(children: [
        const Icon(Icons.network_check_rounded, color: Colors.orange),
        const SizedBox(width: 10),
        Expanded(child: Text(tr('slow_net'))),
        TextButton(
          onPressed: () {
            if (low != null) {
              setQuality(low);
            } else {
              showDownloadSheet(context, url: url, known: video);
            }
          },
          child: Text(low != null ? tr('lower_q') : tr('dl_instead')),
        ),
      ]),
    );
  }

  Widget infoBlock(Video v) => Padding(
        padding: const EdgeInsets.fromLTRB(14, 14, 14, 0),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(v.title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700, height: 1.3)),
          const SizedBox(height: 6),
          Text(
            '${v.author} • ${compact(v.engagement.viewCount)} ${tr('views')} • ${dur(v.duration)}',
            style: const TextStyle(color: Colors.grey, fontSize: 12.5),
          ),
          const SizedBox(height: 14),
          if (slow) slowBanner(),
          Row(children: [
            Expanded(
              child: FilledButton.icon(
                style: FilledButton.styleFrom(backgroundColor: kRed, minimumSize: const Size.fromHeight(46)),
                icon: const Icon(Icons.download_rounded),
                label: Text(tr('download')),
                onPressed: () => showDownloadSheet(context, url: url, known: video),
              ),
            ),
            const SizedBox(width: 8),
            OutlinedButton(
              style: OutlinedButton.styleFrom(minimumSize: const Size(52, 46), padding: EdgeInsets.zero),
              child: const Icon(Icons.music_note_rounded),
              onPressed: () {
                final id = YT.idOf(url);
                if (video != null) {
                  DM.i.addVideo(video!, 'audio');
                } else if (id != null) {
                  DM.i.addId(id, 'audio');
                }
                toast(tr('started'));
              },
            ),
            const SizedBox(width: 8),
            OutlinedButton(
              style: OutlinedButton.styleFrom(minimumSize: const Size(52, 46), padding: EdgeInsets.zero),
              child: const Icon(Icons.share_rounded),
              onPressed: () => Share.share(url),
            ),
          ]),
          if (v.description.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: ExpansionTile(
                tilePadding: EdgeInsets.zero,
                title: Text(tr('description'), style: const TextStyle(fontSize: 14)),
                children: [Text(v.description, style: const TextStyle(color: Colors.white70, height: 1.5))],
              ),
            ),
          if (widget.queue != null) ...[
            const SizedBox(height: 14),
            Text(
              '${tr('up_next')}  (${idx + 1}/${widget.queue!.length})',
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
            ),
            const SizedBox(height: 6),
          ],
        ]),
      );

  Widget queueTile(int i) {
    final x = widget.queue![i];
    return ListTile(
      selected: i == idx,
      selectedColor: kRed,
      selectedTileColor: kRed.withValues(alpha: .08),
      leading: Thumb(x.thumbnails.mediumResUrl, w: 96, h: 54, radius: 8),
      title: Text(x.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 13)),
      subtitle: Text(x.author, style: const TextStyle(fontSize: 11)),
      trailing: IconButton(
        icon: const Icon(Icons.download_rounded, size: 22),
        onPressed: () => quickDownload(context, x),
      ),
      onTap: () => go(i),
    );
  }

  @override
  Widget build(BuildContext context) {
    final v = video;
    final n = widget.queue?.length ?? 0;
    return PopScope(
      canPop: !full,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop && full) toggleFull();
      },
      child: Scaffold(
        backgroundColor: kBg,
        body: full
            ? SizedBox.expand(child: player())
            : SafeArea(
                bottom: false,
                child: Column(children: [
                  player(),
                  Expanded(
                    child: v == null
                        ? const SizedBox()
                        : ListView.builder(
                            padding: const EdgeInsets.only(bottom: 12),
                            itemCount: 1 + n,
                            itemBuilder: (_, i) => i == 0 ? infoBlock(v) : queueTile(i - 1),
                          ),
                  ),
                  const MiniDownloads(),
                ]),
              ),
      ),
    );
  }
}

// ================================================================ download helpers

/// Download button behaviour: instant if a default quality is set, otherwise the quality sheet.
void quickDownload(BuildContext context, Video v) {
  final pref = Prefs.dq;
  if (pref == 'ask') {
    showDownloadSheet(context, url: v.url, known: v);
  } else {
    DM.i.addVideo(v, pref);
    toast(tr('started'));
  }
}

/// Quality picker for batches (playlists). Returns null if dismissed.
Future<String?> askPref(BuildContext context, {bool forceAsk = false}) async {
  if (!forceAsk && Prefs.dq != 'ask') return Prefs.dq;
  return showModalBottomSheet<String>(
    context: context,
    isScrollControlled: true,
    backgroundColor: kCard,
    shape: kSheetShape,
    builder: (c) => SafeArea(
      child: SingleChildScrollView(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Text(tr('pick_quality'), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
          ),
          for (final p in const ['best', '1080', '720', '480', '360', 'audio', 'mp3'])
            ListTile(
              leading: CircleAvatar(
                backgroundColor: kRed.withValues(alpha: .18),
                child: Icon(p == 'audio' || p == 'mp3' ? Icons.music_note_rounded : Icons.videocam_rounded, color: kRed),
              ),
              title: Text(prefLabel(p)),
              onTap: () => Navigator.pop(c, p),
            ),
          const SizedBox(height: 8),
        ]),
      ),
    ),
  );
}

/// Bottom sheet with every video and audio quality. Opens instantly and fills in
/// as soon as the stream list arrives.
void showDownloadSheet(BuildContext context, {required String url, Video? known}) {
  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    backgroundColor: kCard,
    shape: kSheetShape,
    builder: (c) => _DownloadSheet(url: url, known: known),
  );
}

class _DownloadSheet extends StatefulWidget {
  final String url;
  final Video? known;
  const _DownloadSheet({required this.url, this.known});
  @override
  State<_DownloadSheet> createState() => _DownloadSheetState();
}

class _DownloadSheetState extends State<_DownloadSheet> {
  late Future<Meta> f;

  @override
  void initState() {
    super.initState();
    start();
  }

  void start() {
    final id = YT.idOf(widget.url);
    f = id == null ? Future<Meta>.error(Exception('bad url')) : YT.meta(id, known: widget.known);
  }

  Widget tile(BuildContext c, Video v, Opt o, String pref, {String? title, String? sub}) => ListTile(
        leading: CircleAvatar(
          backgroundColor: kRed.withValues(alpha: .18),
          child: Icon(o.isAudio ? Icons.music_note_rounded : Icons.videocam_rounded, color: kRed),
        ),
        title: Text(title ?? (o.isAudio ? '${tr('audio')} ${o.label}' : '${tr('video')} ${o.label}')),
        subtitle: Text(sub ?? '${fmtBytes(o.bytes)} • ${o.outExt.toUpperCase()}${o.kind == 'adaptive' ? ' • ${tr('hd_merge')}' : ''}'),
        trailing: const Icon(Icons.download_rounded),
        onTap: () {
          DM.i.addVideo(v, pref, opt: o);
          Navigator.pop(c);
          toast(tr('started'));
        },
      );

  Widget heading(String t) => Padding(
        padding: const EdgeInsets.fromLTRB(18, 10, 18, 2),
        child: Text(t, style: const TextStyle(color: kRed, fontWeight: FontWeight.w800)),
      );

  @override
  Widget build(BuildContext context) => SafeArea(
        child: ConstrainedBox(
          constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * .85),
          child: FutureBuilder<Meta>(
            future: f,
            builder: (c, s) {
              final v = s.data?.video ?? widget.known;
              final header = Padding(
                padding: const EdgeInsets.all(16),
                child: Row(children: [
                  Thumb(v?.thumbnails.mediumResUrl, w: 120, h: 68, radius: 10),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(v?.title ?? '', maxLines: 3, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.bold)),
                  ),
                ]),
              );
              if (s.hasError) {
                return Column(mainAxisSize: MainAxisSize.min, children: [
                  header,
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
                    child: ErrorState(tr('load_failed'), () => setState(start)),
                  ),
                ]);
              }
              if (!s.hasData) {
                return Column(mainAxisSize: MainAxisSize.min, children: [
                  header,
                  const Padding(padding: EdgeInsets.fromLTRB(16, 16, 16, 40), child: CircularProgressIndicator()),
                ]);
              }
              final m = s.data!.manifest;
              final vid = s.data!.video;
              final vopts = videoOpts(m);
              final aopts = audioOpts(m);
              final mp3 = chooseOpt(m, 'mp3');
              return Column(mainAxisSize: MainAxisSize.min, children: [
                header,
                Flexible(
                  child: ListView(shrinkWrap: true, children: [
                    if (vopts.isNotEmpty) heading(tr('video_q')),
                    for (final o in vopts) tile(c, vid, o, prefOf(o)),
                    if (aopts.isNotEmpty) heading(tr('audio_q')),
                    if (mp3 != null)
                      tile(c, vid, mp3, 'mp3', title: 'MP3 192k', sub: '${tr('mp3_note')} • ${fmtBytes(mp3.bytes)}'),
                    for (final o in aopts) tile(c, vid, o, prefOf(o)),
                    const SizedBox(height: 12),
                  ]),
                ),
              ]);
            },
          ),
        ),
      );
}
