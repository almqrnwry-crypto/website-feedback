import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart' hide Thumb;
import 'core.dart';

class Thumb extends StatelessWidget {
  final String? url;
  final double? h, w;
  final double radius;
  const Thumb(this.url, {super.key, this.h, this.w, this.radius = 0});

  @override
  Widget build(BuildContext context) {
    final ph = Container(
      height: h,
      width: w,
      color: kCard2,
      child: const Icon(Icons.movie_rounded, color: Colors.white24),
    );
    return ClipRRect(
      borderRadius: BorderRadius.circular(radius),
      child: url == null
          ? ph
          : CachedNetworkImage(
              imageUrl: url!,
              height: h,
              width: w,
              fit: BoxFit.cover,
              fadeInDuration: const Duration(milliseconds: 150),
              placeholder: (_, __) => Container(height: h, width: w, color: kCard2),
              errorWidget: (_, __, ___) => ph,
            ),
    );
  }
}

class Pulse extends StatefulWidget {
  final Widget child;
  const Pulse({super.key, required this.child});
  @override
  State<Pulse> createState() => _PulseState();
}

class _PulseState extends State<Pulse> with SingleTickerProviderStateMixin {
  late final AnimationController c = AnimationController(vsync: this, duration: const Duration(milliseconds: 900))
    ..repeat(reverse: true);

  @override
  void dispose() {
    c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) =>
      FadeTransition(opacity: Tween<double>(begin: .35, end: 1).animate(c), child: widget.child);
}

class SkeletonCard extends StatelessWidget {
  const SkeletonCard({super.key});
  @override
  Widget build(BuildContext context) => Pulse(
        child: Container(
          margin: const EdgeInsets.only(bottom: 14),
          decoration: BoxDecoration(color: kCard, borderRadius: BorderRadius.circular(18)),
          clipBehavior: Clip.antiAlias,
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Container(height: 190, color: kCard2),
            Padding(
              padding: const EdgeInsets.all(12),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Container(height: 14, width: 240, decoration: BoxDecoration(color: kCard2, borderRadius: BorderRadius.circular(6))),
                const SizedBox(height: 8),
                Container(height: 11, width: 140, decoration: BoxDecoration(color: kCard2, borderRadius: BorderRadius.circular(6))),
              ]),
            ),
          ]),
        ),
      );
}

class EmptyState extends StatelessWidget {
  final IconData icon;
  final String text;
  const EmptyState(this.icon, this.text, {super.key});
  @override
  Widget build(BuildContext context) => Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, size: 72, color: Colors.white24),
          const SizedBox(height: 12),
          Text(text, style: const TextStyle(color: Colors.grey)),
        ]),
      );
}

class ErrorState extends StatelessWidget {
  final String text;
  final VoidCallback onRetry;
  const ErrorState(this.text, this.onRetry, {super.key});
  @override
  Widget build(BuildContext context) => Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Icon(Icons.wifi_off_rounded, size: 56, color: Colors.white24),
          const SizedBox(height: 10),
          Text(text, textAlign: TextAlign.center),
          const SizedBox(height: 12),
          FilledButton(onPressed: onRetry, child: Text(tr('retry'))),
        ]),
      );
}

class Badge2 extends StatelessWidget {
  final String text;
  final Color? color;
  const Badge2(this.text, {super.key, this.color});
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
        decoration: BoxDecoration(color: (color ?? kRed).withValues(alpha: .18), borderRadius: BorderRadius.circular(8)),
        child: Text(text, style: TextStyle(fontSize: 11, color: color ?? kRed, fontWeight: FontWeight.w700)),
      );
}
