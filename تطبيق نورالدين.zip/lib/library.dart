import 'dart:io';
import 'package:flutter/material.dart' hide Thumb;
import 'package:share_plus/share_plus.dart';
import 'core.dart';
import 'engine.dart';
import 'player.dart';
import 'ui.dart';

// ---------------------------------------------------------------- Downloads
class DownloadsPage extends StatelessWidget {
  const DownloadsPage({super.key});

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: DM.i,
        builder: (c, _) {
          final l = DM.i.items;
          final busy = l.where((e) => e.status == 'downloading' || e.status == 'queued').toList();
          final fin = l.where((e) => e.status != 'downloading' && e.status != 'queued').toList();
          return Scaffold(
            appBar: AppBar(
              title: Text(tr('downloads')),
              actions: [
                if (l.isNotEmpty)
                  PopupMenuButton<String>(
                    onSelected: (s) {
                      if (s == 'clear') DM.i.clearFinished();
                      if (s == 'retry') DM.i.retryFailed();
                      if (s == 'cancel') DM.i.cancelAll();
                    },
                    itemBuilder: (_) => [
                      if (busy.isNotEmpty) PopupMenuItem(value: 'cancel', child: Text(tr('cancel_all'))),
                      if (l.any((e) => e.status == 'error')) PopupMenuItem(value: 'retry', child: Text(tr('retry_failed'))),
                      if (fin.isNotEmpty) PopupMenuItem(value: 'clear', child: Text(tr('clear_done'))),
                    ],
                  ),
              ],
            ),
            body: l.isEmpty
                ? EmptyState(Icons.cloud_download_outlined, tr('no_downloads'))
                : ListView(padding: const EdgeInsets.all(12), children: [
                    if (busy.isNotEmpty) section(tr('active'), busy.length),
                    for (final d in busy) tile(c, d),
                    if (fin.isNotEmpty) section(tr('finished'), fin.length),
                    for (final d in fin) tile(c, d),
                  ]),
          );
        },
      );

  Widget section(String t, int n) => Padding(
        padding: const EdgeInsets.fromLTRB(4, 8, 4, 8),
        child: Text('$t  ($n)', style: const TextStyle(fontWeight: FontWeight.w800, color: Colors.grey)),
      );

  Widget sub(Dl d) {
    switch (d.status) {
      case 'downloading':
        if (d.merging) {
          return Padding(
            padding: const EdgeInsets.only(top: 8),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(tr('merging'), style: const TextStyle(fontSize: 12, color: Colors.grey)),
              const SizedBox(height: 6),
              const LinearProgressIndicator(minHeight: 4),
            ]),
          );
        }
        if (d.resolving || (d.total <= 0 && d.got == 0)) {
          return Padding(
            padding: const EdgeInsets.only(top: 8),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(tr('resolving'), style: const TextStyle(fontSize: 12, color: Colors.grey)),
              const SizedBox(height: 6),
              const LinearProgressIndicator(minHeight: 4),
            ]),
          );
        }
        final eta = d.speed > 0 && d.total > 0 ? fmtEta(((d.total - d.got) / d.speed).round()) : '';
        return Padding(
          padding: const EdgeInsets.only(top: 8),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            LinearProgressIndicator(
              value: d.total > 0 ? d.progress : null,
              minHeight: 4,
              borderRadius: BorderRadius.circular(4),
            ),
            const SizedBox(height: 6),
            Text(
              '${fmtBytes(d.got)}${d.total > 0 ? ' / ${fmtBytes(d.total)}' : ''}'
              '${d.speed > 0 ? '  •  ${fmtBytes(d.speed)}/s' : ''}'
              '${eta.isNotEmpty ? '  •  $eta ${tr('left')}' : ''}',
              style: const TextStyle(fontSize: 11.5, color: Colors.grey),
            ),
          ]),
        );
      case 'queued':
        return Text(tr('queued'), style: const TextStyle(fontSize: 12, color: Colors.grey));
      case 'done':
        return Text('${d.ext.toUpperCase()} • ${fmtBytes(d.total > 0 ? d.total : d.got)}', style: const TextStyle(fontSize: 12, color: Colors.grey));
      case 'error':
        return Text(
          '${tr('failed')}${d.err != null ? ': ${d.err!.length > 70 ? d.err!.substring(0, 70) : d.err}' : ''}',
          maxLines: 2,
          style: const TextStyle(fontSize: 12, color: Colors.orange),
        );
      default:
        return Text(tr('canceled'), style: const TextStyle(fontSize: 12, color: Colors.grey));
    }
  }

  Widget tile(BuildContext c, Dl d) {
    final busy = d.status == 'downloading' || d.status == 'queued';
    final color = d.status == 'done' ? Colors.green : (d.status == 'error' ? Colors.orange : kRed);
    return Card(
      color: kCard,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: ListTile(
        contentPadding: const EdgeInsetsDirectional.fromSTEB(12, 6, 6, 6),
        leading: d.thumb != null
            ? Thumb(d.thumb, w: 64, h: 48, radius: 10)
            : Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(color: color.withValues(alpha: .18), borderRadius: BorderRadius.circular(12)),
                child: Icon(d.status == 'done' ? Icons.check_circle_rounded : Icons.downloading_rounded, color: color),
              ),
        title: Text(d.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 14)),
        subtitle: sub(d),
        trailing: busy
            ? Row(mainAxisSize: MainAxisSize.min, children: [
                if (d.status == 'downloading' && !d.resolving && !d.merging && d.total > 0) Text('${(d.progress * 100).round()}%'),
                IconButton(icon: const Icon(Icons.close_rounded), tooltip: tr('cancel'), onPressed: () => DM.i.cancelItem(d)),
              ])
            : (d.status == 'error' || d.status == 'canceled')
                ? IconButton(icon: const Icon(Icons.refresh_rounded), tooltip: tr('retry'), onPressed: () => DM.i.retry(d))
                : IconButton(icon: const Icon(Icons.share_rounded), tooltip: tr('share'), onPressed: () => Share.shareXFiles([XFile(d.path)])),
        onTap: d.status == 'done' ? () => Navigator.push(c, MaterialPageRoute(builder: (_) => PlayerPage(file: File(d.path)))) : null,
      ),
    );
  }
}

// ---------------------------------------------------------------- Library
class LibItem {
  final File f;
  final int size;
  final DateTime mod;
  LibItem(this.f, this.size, this.mod);
  String get file => f.path.split('/').last;
  String get ext => file.contains('.') ? file.split('.').last.toLowerCase() : '';
  String get name => file.contains('.') ? file.substring(0, file.lastIndexOf('.')) : file;
  bool get audio => const ['m4a', 'mp3', 'weba', 'opus', 'ogg', 'aac'].contains(ext);
}

class LibraryPage extends StatefulWidget {
  const LibraryPage({super.key});
  @override
  State<LibraryPage> createState() => _LibraryPageState();
}

class _LibraryPageState extends State<LibraryPage> {
  List<LibItem> items = [];
  Map<String, dynamic> thumbs = {};
  String type = 'all';
  String sort = 'new';
  String q = '';

  @override
  void initState() {
    super.initState();
    refresh();
    DM.i.done.addListener(refresh); // only when a download finishes (not on every progress tick)
  }

  @override
  void dispose() {
    DM.i.done.removeListener(refresh);
    super.dispose();
  }

  Future<void> refresh() async {
    try {
      final d = await DM.i.dir();
      final out = <LibItem>[];
      await for (final e in d.list()) {
        if (e is File && !e.path.endsWith('.part') && !e.path.endsWith('.tmp') && !e.path.endsWith('.mrg')) {
          final s = await e.stat();
          out.add(LibItem(e, s.size, s.modified));
        }
      }
      if (mounted) {
        setState(() {
          items = out;
          thumbs = Prefs.thumbs();
        });
      }
    } catch (_) {}
  }

  Future<void> remove(LibItem it) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: Text(tr('delete_q')),
        content: Text(it.file),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: Text(tr('no'))),
          TextButton(onPressed: () => Navigator.pop(c, true), child: Text(tr('yes'))),
        ],
      ),
    );
    if (ok == true) {
      try {
        await it.f.delete();
      } catch (_) {}
      refresh();
    }
  }

  @override
  Widget build(BuildContext context) {
    final shown = items.where((f) {
      if (q.isNotEmpty && !f.name.toLowerCase().contains(q.toLowerCase())) return false;
      if (type == 'video') return !f.audio;
      if (type == 'audio') return f.audio;
      return true;
    }).toList();
    shown.sort((a, b) {
      if (sort == 'name') return a.name.toLowerCase().compareTo(b.name.toLowerCase());
      if (sort == 'size') return b.size.compareTo(a.size);
      return b.mod.compareTo(a.mod);
    });
    final total = items.fold<int>(0, (a, f) => a + f.size);
    return Scaffold(
      appBar: AppBar(
        title: Text(tr('library')),
        actions: [
          PopupMenuButton<String>(
            icon: const Icon(Icons.sort_rounded),
            onSelected: (s) => setState(() => sort = s),
            itemBuilder: (_) => [
              CheckedPopupMenuItem(value: 'new', checked: sort == 'new', child: Text(tr('sort_new'))),
              CheckedPopupMenuItem(value: 'name', checked: sort == 'name', child: Text(tr('sort_name'))),
              CheckedPopupMenuItem(value: 'size', checked: sort == 'size', child: Text(tr('sort_size'))),
            ],
          ),
          IconButton(icon: const Icon(Icons.refresh_rounded), onPressed: refresh),
        ],
      ),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 4, 12, 0),
          child: TextField(
            onChanged: (v) => setState(() => q = v),
            decoration: InputDecoration(
              isDense: true,
              filled: true,
              fillColor: kCard,
              hintText: tr('search_in_library'),
              prefixIcon: const Icon(Icons.search_rounded),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(24), borderSide: BorderSide.none),
            ),
          ),
        ),
        SizedBox(
          height: 48,
          child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 10), children: [
            for (final t in const [('all', 'all'), ('video', 'video'), ('audio', 'audio')])
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 8),
                child: ChoiceChip(
                  label: Text(tr(t.$2)),
                  selected: type == t.$1,
                  selectedColor: kRed,
                  onSelected: (_) => setState(() => type = t.$1),
                ),
              ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8),
              child: Center(
                child: Text(
                  '${items.length} ${tr('files_n')} • ${tr('storage')}: ${fmtBytes(total)}',
                  style: const TextStyle(fontSize: 12, color: Colors.grey),
                ),
              ),
            ),
          ]),
        ),
        Expanded(
          child: shown.isEmpty
              ? EmptyState(Icons.video_library_outlined, tr('library_empty'))
              : ListView.builder(
                  padding: const EdgeInsets.all(12),
                  itemCount: shown.length,
                  itemBuilder: (_, i) => card(shown[i]),
                ),
        ),
      ]),
    );
  }

  Widget card(LibItem it) {
    final th = thumbs[it.file] as String?;
    return Card(
      color: kCard,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: ListTile(
        contentPadding: const EdgeInsetsDirectional.fromSTEB(12, 6, 4, 6),
        leading: th != null
            ? Stack(alignment: Alignment.center, children: [
                Thumb(th, w: 72, h: 52, radius: 10),
                Icon(it.audio ? Icons.music_note_rounded : Icons.play_circle_fill_rounded, color: Colors.white70),
              ])
            : Container(
                width: 52,
                height: 52,
                decoration: BoxDecoration(color: kRed.withValues(alpha: .18), borderRadius: BorderRadius.circular(12)),
                child: Icon(it.audio ? Icons.music_note_rounded : Icons.play_circle_fill_rounded, color: kRed),
              ),
        title: Text(it.name, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 14)),
        subtitle: Padding(
          padding: const EdgeInsets.only(top: 4),
          child: Row(children: [
            Badge2(it.ext.toUpperCase()),
            const SizedBox(width: 8),
            Text(fmtBytes(it.size), style: const TextStyle(fontSize: 12, color: Colors.grey)),
          ]),
        ),
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PlayerPage(file: it.f))),
        trailing: PopupMenuButton<String>(
          onSelected: (s) {
            if (s == 'share') Share.shareXFiles([XFile(it.f.path)]);
            if (s == 'delete') remove(it);
          },
          itemBuilder: (_) => [
            PopupMenuItem(value: 'share', child: Text(tr('share'))),
            PopupMenuItem(value: 'delete', child: Text(tr('delete'))),
          ],
        ),
      ),
    );
  }
}
