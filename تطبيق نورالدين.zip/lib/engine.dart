import 'dart:async';
import 'dart:io';
import 'package:ffmpeg_kit_flutter_new/ffmpeg_kit.dart';
import 'package:ffmpeg_kit_flutter_new/return_code.dart';
import 'package:flutter/foundation.dart';
import 'package:gal/gal.dart';
import 'package:path_provider/path_provider.dart';
import 'package:youtube_explode_dart/youtube_explode_dart.dart';
import 'core.dart';

// ================================================================ metadata
class Meta {
  final Video video;
  final StreamManifest manifest;
  final DateTime at = DateTime.now();
  Meta(this.video, this.manifest);
}

/// Shared YouTube client with a cache: video info + stream list are fetched
/// IN PARALLEL (the old code fetched them one after another), reused for
/// watching and downloading, and de-duplicated if requested twice.
class YT {
  static final yt = YoutubeExplode();
  static final _cache = <String, Meta>{};
  static final _pending = <String, Future<Meta>>{};

  static String? idOf(String s) {
    try {
      return VideoId(s).value;
    } catch (_) {
      return null;
    }
  }

  static Future<Meta> meta(String idOrUrl, {Video? known}) {
    final id = idOf(idOrUrl) ?? idOrUrl;
    final c = _cache[id];
    if (c != null && DateTime.now().difference(c.at).inMinutes < 90) return Future.value(c);
    final p = _pending[id];
    if (p != null) return p;
    final f = _fetch(id, known).whenComplete(() {
      _pending.remove(id);
    });
    _pending[id] = f;
    return f;
  }

  static Future<StreamManifest> _manifest(String id) async {
    try {
      return await yt.videos.streamsClient.getManifest(id);
    } catch (_) {
      await Future.delayed(const Duration(milliseconds: 900));
      return await yt.videos.streamsClient.getManifest(id);
    }
  }

  static Future<Meta> _fetch(String id, Video? known) async {
    final vF = known != null ? Future<Video>.value(known) : yt.videos.get(id);
    final mF = _manifest(id);
    final r = await Future.wait<Object>([vF, mF]).timeout(const Duration(seconds: 35));
    final m = Meta(r[0] as Video, r[1] as StreamManifest);
    if (_cache.length > 40) _cache.remove(_cache.keys.first);
    _cache[id] = m;
    return m;
  }
}

// ================================================================ streams
String extFor(StreamInfo x, {bool audio = false}) {
  final c = x.container.name;
  if (!audio) return c;
  if (c == 'mp4') return 'm4a';
  if (c == 'webm') return 'weba';
  return c;
}

List<MuxedStreamInfo> muxedSorted(StreamManifest m) {
  final l = m.muxed.toList();
  l.sort((a, b) => b.videoResolution.height.compareTo(a.videoResolution.height));
  return l;
}

List<AudioOnlyStreamInfo> audioSorted(StreamManifest m) {
  final l = m.audioOnly.toList();
  l.sort((a, b) => b.bitrate.bitsPerSecond.compareTo(a.bitrate.bitsPerSecond));
  return l;
}

/// One selectable quality: a ready muxed stream, an HD pair (video-only + audio,
/// merged after download / played in sync), or an audio-only stream.
class Opt {
  final String kind; // muxed | adaptive | audio
  final String label;
  final StreamInfo main;
  final StreamInfo? audio;
  final int height;
  Opt(this.kind, this.label, this.main, {this.audio, this.height = 0});
  int get bytes => main.size.totalBytes + (audio?.size.totalBytes ?? 0);
  bool get isAudio => kind == 'audio';
  String get outExt {
    if (isAudio) return extFor(main, audio: true);
    if (kind == 'muxed') return main.container.name;
    return main.container.name == 'mp4' ? 'mp4' : 'mkv';
  }
}

const _h264 = <int>{160, 133, 134, 135, 136, 137, 264, 266, 298, 299, 304, 305};
const _vp9 = <int>{278, 242, 243, 244, 247, 248, 271, 313, 302, 303, 308, 315};

AudioOnlyStreamInfo? bestM4a(StreamManifest m) {
  final a = audioSorted(m).where((x) => x.container.name == 'mp4').toList();
  return a.isEmpty ? null : a.first;
}

/// All video qualities, best first (muxed + HD adaptive; AV1 is skipped because many phones can't decode it).
List<Opt> videoOpts(StreamManifest m) {
  final out = <Opt>[];
  final seen = <int>{};
  for (final x in muxedSorted(m)) {
    out.add(Opt('muxed', x.videoQualityLabel, x, height: x.videoResolution.height));
    seen.add(x.videoResolution.height);
  }
  final aud = bestM4a(m);
  if (aud != null) {
    final byH = <int, VideoOnlyStreamInfo>{};
    for (final x in m.videoOnly) {
      if (!_h264.contains(x.tag) && !_vp9.contains(x.tag)) continue;
      final h = x.videoResolution.height;
      final cur = byH[h];
      if (cur == null) {
        byH[h] = x;
      } else {
        final better = (_vp9.contains(cur.tag) && _h264.contains(x.tag)) ||
            (_h264.contains(cur.tag) == _h264.contains(x.tag) && x.bitrate.bitsPerSecond > cur.bitrate.bitsPerSecond);
        if (better) byH[h] = x;
      }
    }
    for (final e in byH.entries) {
      if (seen.contains(e.key) || e.key < 144) continue;
      out.add(Opt('adaptive', e.value.videoQualityLabel, e.value, audio: aud, height: e.key));
    }
  }
  out.sort((a, b) => b.height.compareTo(a.height));
  return out;
}

/// Every audio stream (music qualities), best first.
List<Opt> audioOpts(StreamManifest m) => [
      for (final x in audioSorted(m))
        Opt('audio', '${x.container.name == 'mp4' ? 'M4A' : 'OPUS'} ${x.bitrate.kiloBitsPerSecond.round()}k', x),
    ];

/// Index to START playing with. Single-stream (muxed) qualities start fastest;
/// HD is chosen manually from the quality menu or with the "highest" setting.
int pickStart(List<Opt> o, String mode, bool mobile) {
  final vids = [for (var i = 0; i < o.length; i++) if (!o[i].isAudio) i];
  if (vids.isEmpty) return 0;
  if (mode == 'high') return vids.first;
  if (mode == 'low') return vids.last; // smallest = max data saving
  final cap = mobile ? 360 : 720;
  final muxed = vids.where((i) => o[i].kind == 'muxed').toList();
  final pool = muxed.isNotEmpty ? muxed : vids;
  for (final i in pool) {
    if (o[i].height <= cap) return i;
  }
  return pool.last;
}

String prefOf(Opt o) => o.isAudio ? 'a:${o.main.tag}' : '${o.height}';

/// Resolves a quality preference (best | 1080 | 720 | ... | audio | mp3 | a:<itag>) to a real option.
Opt? chooseOpt(StreamManifest m, String pref) {
  if (pref == 'audio' || pref == 'mp3' || pref.startsWith('a:')) {
    final l = audioOpts(m);
    if (l.isEmpty) return null;
    if (pref.startsWith('a:')) {
      final tag = int.tryParse(pref.substring(2));
      for (final o in l) {
        if (o.main.tag == tag) return o;
      }
    }
    final mp4 = l.where((o) => o.main.container.name == 'mp4').toList();
    return mp4.isNotEmpty ? mp4.first : l.first;
  }
  final v = videoOpts(m);
  if (v.isEmpty) return null;
  final h = int.tryParse(pref);
  if (h == null) return v.first;
  for (final o in v) {
    if (o.height <= h) return o;
  }
  return v.last;
}

// ================================================================ downloads
class Dl {
  int seq;
  String title;
  String pref;
  String? videoId, url, thumb, err;
  Video? video;
  Opt? opt;
  String path = '', ext = '';
  double progress = 0, speed = 0;
  int got = 0, total = 0;
  String status = 'queued'; // queued | downloading | done | error | canceled
  bool resolving = false, merging = false, cancel = false;

  Dl({required this.seq, required this.title, required this.pref, this.videoId, this.url, this.video, this.opt, this.thumb});

  String get fileName => path.split('/').last;
}

/// Download manager. Items are added INSTANTLY (even a 500-video playlist);
/// each video is resolved when its turn comes (one resolve at a time, with
/// retries, so YouTube does not block bulk requests). Files are written to
/// temporary names and only appear in the library when complete.
class DM extends ChangeNotifier {
  static final i = DM._();
  DM._();

  final items = <Dl>[];
  final done = ValueNotifier<int>(0); // bumped when a file completes (library refresh)
  Directory? _dir;
  int _seq = 0;
  Future<void> _gate = Future.value();

  int get active => items.where((e) => e.status == 'downloading' || e.status == 'queued').length;

  void kick() => _pump();

  Future<void> init() async {
    try {
      final d = await dir();
      await for (final e in d.list()) {
        if (e is File && (e.path.endsWith('.part') || e.path.endsWith('.tmp') || e.path.endsWith('.mrg'))) {
          await _rm(e.path);
        }
      }
    } catch (_) {}
  }

  Future<Directory> dir() async {
    if (_dir != null) return _dir!;
    final d = await getApplicationDocumentsDirectory();
    final x = Directory('${d.path}/NooruddinTop');
    if (!await x.exists()) await x.create(recursive: true);
    _dir = x;
    return x;
  }

  Future<void> _rm(String p) async {
    try {
      final f = File(p);
      if (await f.exists()) await f.delete();
    } catch (_) {}
  }

  String clean(String s) {
    var t = s.replaceAll(RegExp(r'[\\/:*?"<>|\n\r\t]'), ' ').replaceAll(RegExp(r'\s+'), ' ').trim();
    if (t.length > 90) t = t.substring(0, 90).trim();
    return t.isEmpty ? 'video' : t;
  }

  String _pathFor(Dl d) {
    final base = clean(d.title);
    var p = '${_dir!.path}/$base.${d.ext}';
    var n = 1;
    bool taken(String x) =>
        File(x).existsSync() ||
        File('$x.part').existsSync() ||
        items.any((e) => !identical(e, d) && e.path == x && e.status != 'error' && e.status != 'canceled');
    while (taken(p)) {
      p = '${_dir!.path}/$base ($n).${d.ext}';
      n++;
    }
    return p;
  }

  bool _dupe(String id, String pref) =>
      items.any((e) => e.videoId == id && e.pref == pref && (e.status == 'queued' || e.status == 'downloading'));

  Dl _mk({String? id, Video? v, String? url, String? title, required String pref, Opt? opt}) => Dl(
        seq: _seq++,
        title: v?.title ?? title ?? 'video',
        pref: pref,
        videoId: id,
        url: url,
        video: v,
        opt: opt,
        thumb: v?.thumbnails.mediumResUrl,
      );

  void addVideo(Video v, String pref, {Opt? opt}) {
    if (opt == null && _dupe(v.id.value, pref)) return;
    items.insert(0, _mk(id: v.id.value, v: v, pref: pref, opt: opt));
    _pump();
  }

  /// Adds many videos at once. Returns how many were really added.
  int addVideos(List<Video> vs, String pref) {
    final l = <Dl>[];
    for (final v in vs) {
      if (_dupe(v.id.value, pref)) continue;
      l.add(_mk(id: v.id.value, v: v, pref: pref));
    }
    items.insertAll(0, l);
    _pump();
    return l.length;
  }

  void addId(String id, String pref) {
    if (_dupe(id, pref)) return;
    items.insert(0, _mk(id: id, pref: pref, title: 'YouTube $id'));
    _pump();
  }

  Future<void> addDirect(String url) async {
    await dir();
    final segs = Uri.parse(url).pathSegments;
    final name = segs.isEmpty || segs.last.isEmpty ? 'file' : segs.last;
    final hasExt = name.contains('.') && name.split('.').last.length <= 5;
    final ext = hasExt ? name.split('.').last.toLowerCase() : 'mp4';
    final base = hasExt ? name.substring(0, name.lastIndexOf('.')) : name;
    final d = _mk(url: url, title: base, pref: 'best');
    d.ext = ext;
    d.path = _pathFor(d);
    items.insert(0, d);
    _pump();
  }

  void cancelItem(Dl d) {
    d.cancel = true;
    if (d.status == 'queued') d.status = 'canceled';
    notifyListeners();
  }

  void cancelAll() {
    for (final d in items) {
      if (d.status == 'queued' || d.status == 'downloading') cancelItem(d);
    }
  }

  void retry(Dl d) {
    d.status = 'queued';
    d.progress = 0;
    d.got = 0;
    d.speed = 0;
    d.err = null;
    d.cancel = false;
    d.seq = _seq++;
    if (d.videoId != null) d.opt = null;
    _pump();
  }

  void retryFailed() {
    for (final d in items.where((e) => e.status == 'error').toList()) {
      retry(d);
    }
  }

  void clearFinished() {
    items.removeWhere((e) => e.status == 'done' || e.status == 'error' || e.status == 'canceled');
    notifyListeners();
  }

  void _pump() {
    final par = Prefs.parallel;
    var running = items.where((e) => e.status == 'downloading').length;
    final q = items.where((e) => e.status == 'queued').toList()..sort((a, b) => a.seq.compareTo(b.seq));
    for (final d in q) {
      if (running >= par) break;
      d.status = 'downloading';
      running++;
      _run(d);
    }
    notifyListeners();
  }

  /// Runs [f] after every earlier call finished, with a small gap (anti rate-limit).
  Future<T> _serial<T>(Future<T> Function() f) {
    final c = Completer<T>();
    _gate = _gate.then((_) async {
      try {
        c.complete(await f());
      } catch (e, st) {
        c.completeError(e, st);
      }
      await Future.delayed(const Duration(milliseconds: 450));
    });
    return c.future;
  }

  Future<Meta> _resolve(Dl d) async {
    Object? last;
    for (var t = 0; t < 4; t++) {
      if (d.cancel) throw Exception('canceled');
      try {
        final known = t < 2 ? d.video : null;
        return await _serial(() => YT.meta(d.videoId!, known: known));
      } catch (e) {
        last = e;
        await Future.delayed(Duration(milliseconds: 1500 * (t + 1)));
      }
    }
    throw last ?? Exception('resolve failed');
  }

  Future<void> _run(Dl d) async {
    try {
      await dir();
      for (var t = 0;; t++) {
        try {
          await _transfer(d);
          break;
        } catch (e) {
          if (d.path.isNotEmpty) await _rm('${d.path}.part');
          if (d.cancel || t >= 2) rethrow;
          if (d.videoId != null) d.opt = null; // fresh (non-expired) stream URLs
          d.got = 0;
          d.progress = 0;
          d.speed = 0;
          notifyListeners();
          await Future.delayed(Duration(seconds: 2 + 2 * t));
        }
      }
      if (d.cancel) {
        d.status = 'canceled';
        if (d.path.isNotEmpty) await _rm('${d.path}.part');
      } else {
        await File('${d.path}.part').rename(d.path);
        d.status = 'done';
        d.progress = 1;
        if (d.thumb != null) await Prefs.setThumb(d.fileName, d.thumb!);
        if (Prefs.gallery && d.ext == 'mp4') {
          try {
            await Gal.putVideo(d.path, album: 'Nooruddin Top');
          } catch (_) {}
        }
        done.value++;
      }
    } catch (e) {
      if (d.cancel) {
        d.status = 'canceled';
      } else {
        d.status = 'error';
        d.err = e.toString().replaceFirst('Exception: ', '');
      }
      if (d.path.isNotEmpty) await _rm('${d.path}.part');
    }
    d.resolving = false;
    d.merging = false;
    d.speed = 0;
    _pump();
  }

  /// Writes [s] to [f]; progress counts on top of what [d] already downloaded
  /// (so HD video + audio share one progress bar).
  Future<void> _pull(Dl d, Stream<List<int>> s, File f) async {
    IOSink? sink;
    try {
      sink = f.openWrite();
      var last = DateTime.now();
      var lastBytes = d.got;
      await for (final c in s.timeout(const Duration(seconds: 75))) {
        if (d.cancel) break;
        sink.add(c);
        d.got += c.length;
        d.progress = d.total > 0 ? (d.got / d.total).clamp(0.0, 1.0).toDouble() : 0;
        final now = DateTime.now();
        final ms = now.difference(last).inMilliseconds;
        if (ms >= 500) {
          final inst = (d.got - lastBytes) * 1000 / ms;
          d.speed = d.speed == 0 ? inst : d.speed * 0.6 + inst * 0.4;
          last = now;
          lastBytes = d.got;
          notifyListeners();
        }
      }
      await sink.flush();
      await sink.close();
      sink = null;
    } finally {
      try {
        await sink?.close();
      } catch (_) {}
    }
  }

  /// One download attempt. Returns normally on success OR on user cancel.
  Future<void> _transfer(Dl d) async {
    if (d.url != null) {
      await _direct(d);
      return;
    }
    if (d.opt == null) {
      d.resolving = true;
      notifyListeners();
      final m = await _resolve(d);
      if (d.cancel) return;
      d.video ??= m.video;
      d.title = m.video.title;
      d.thumb = m.video.thumbnails.mediumResUrl;
      final o = chooseOpt(m.manifest, d.pref);
      if (o == null) throw Exception('no stream available');
      d.opt = o;
      d.resolving = false;
    }
    final o = d.opt!;
    final mp3 = d.pref == 'mp3' && o.isAudio;
    final ext = mp3 ? 'mp3' : o.outExt;
    d.total = o.bytes;
    if (d.path.isEmpty || d.ext != ext) {
      d.ext = ext;
      d.path = _pathFor(d);
    }
    notifyListeners();

    final parts = <StreamInfo>[o.main, if (o.audio != null) o.audio!];
    final multi = parts.length > 1 || mp3;
    final tmps = <File>[];
    try {
      d.got = 0;
      for (var k = 0; k < parts.length; k++) {
        final f = File(multi ? '${_dir!.path}/t${d.seq}_$k.tmp' : '${d.path}.part');
        tmps.add(f);
        await _pull(d, YT.yt.videos.streamsClient.get(parts[k]), f);
        if (d.cancel) return;
      }
      if (d.total > 0 && d.got < d.total * 0.97) throw Exception('incomplete download');
      if (parts.length > 1) {
        await _merge(d, tmps[0], tmps[1], o);
      } else if (mp3) {
        await _toMp3(d, tmps[0], o);
      }
    } finally {
      if (multi) {
        for (final f in tmps) {
          await _rm(f.path);
        }
      }
    }
  }

  /// HD: video-only + audio -> one file (stream copy, no re-encoding: fast).
  Future<void> _merge(Dl d, File v, File a, Opt o) async {
    d.merging = true;
    d.speed = 0;
    notifyListeners();
    final out = '${_dir!.path}/o${d.seq}.mrg';
    final fmt = o.outExt == 'mp4' ? '-f mp4 -movflags +faststart' : '-f matroska';
    try {
      final s = await FFmpegKit.execute('-y -i "${v.path}" -i "${a.path}" -map 0:v:0 -map 1:a:0 -c copy $fmt "$out"');
      final rc = await s.getReturnCode();
      if (!ReturnCode.isSuccess(rc)) throw Exception('merge failed');
      await File(out).rename('${d.path}.part');
    } catch (e) {
      await _rm(out);
      rethrow;
    } finally {
      d.merging = false;
    }
  }

  /// Music: convert to MP3 192k. If the converter is unavailable the original M4A/Opus is kept.
  Future<void> _toMp3(Dl d, File src, Opt o) async {
    d.merging = true;
    notifyListeners();
    final out = '${_dir!.path}/o${d.seq}.mrg';
    var ok = false;
    try {
      final s = await FFmpegKit.execute('-y -i "${src.path}" -vn -c:a libmp3lame -b:a 192k -f mp3 "$out"');
      ok = ReturnCode.isSuccess(await s.getReturnCode());
    } catch (_) {
      ok = false;
    }
    d.merging = false;
    if (ok) {
      await File(out).rename('${d.path}.part');
    } else {
      await _rm(out);
      d.ext = o.outExt;
      d.path = _pathFor(d);
      await src.copy('${d.path}.part');
    }
  }

  Future<void> _direct(Dl d) async {
    HttpClient? hc;
    try {
      hc = HttpClient()..connectionTimeout = const Duration(seconds: 20);
      final req = await hc.getUrl(Uri.parse(d.url!));
      final res = await req.close();
      if (res.statusCode >= 400) throw Exception('HTTP ${res.statusCode}');
      d.total = res.contentLength;
      d.got = 0;
      notifyListeners();
      await _pull(d, res, File('${d.path}.part'));
    } finally {
      hc?.close(force: true);
    }
  }
}
