import 'dart:async';
import 'package:flutter/material.dart' hide Thumb;
import 'package:youtube_explode_dart/youtube_explode_dart.dart';
import 'core.dart';
import 'engine.dart';
import 'ui.dart';
import 'watch.dart';

/// A playlist or a channel's uploads. Loads in pages, supports selecting
/// videos, and "download all" adds every video to the queue instantly.
class CollectionPage extends StatefulWidget {
  final String title;
  final String? thumb;
  final bool channel;
  final Stream<Video> Function() loader;
  const CollectionPage({super.key, required this.title, required this.loader, this.thumb, this.channel = false});
  @override
  State<CollectionPage> createState() => _CollectionPageState();
}

class _CollectionPageState extends State<CollectionPage> {
  final vids = <Video>[];
  final sel = <int>{};
  final scroll = ScrollController();
  StreamIterator<Video>? it;
  bool loading = true, more = false, done = false, selecting = false, fetchingAll = false;
  String? error;

  @override
  void initState() {
    super.initState();
    scroll.addListener(() {
      if (scroll.hasClients && scroll.position.pixels > scroll.position.maxScrollExtent - 600) loadMore();
    });
    loadMore();
  }

  @override
  void dispose() {
    it?.cancel();
    scroll.dispose();
    super.dispose();
  }

  void reload() {
    it?.cancel();
    it = null;
    vids.clear();
    sel.clear();
    done = false;
    more = false;
    error = null;
    setState(() => loading = true);
    loadMore();
  }

  Future<void> loadMore({int n = 60}) async {
    if (more || done) return;
    more = true;
    if (mounted) setState(() {});
    try {
      it ??= StreamIterator<Video>(widget.loader());
      var c = 0;
      while (c < n && await it!.moveNext()) {
        vids.add(it!.current);
        c++;
      }
      if (c < n) done = true;
    } catch (_) {
      done = true;
      if (vids.isEmpty) error = tr('load_failed');
    }
    more = false;
    loading = false;
    if (mounted) setState(() {});
  }

  /// Makes sure the whole list is loaded (up to 1000 videos).
  Future<List<Video>> all() async {
    if (!done) {
      if (mounted) setState(() => fetchingAll = true);
      while (!done && vids.length < 1000 && mounted) {
        if (more) {
          await Future.delayed(const Duration(milliseconds: 150));
          continue;
        }
        await loadMore(n: 100);
      }
      if (mounted) setState(() => fetchingAll = false);
    }
    return List<Video>.of(vids);
  }

  void play(int i) => Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => WatchPage(url: vids[i].url, queue: vids, index: i)),
      );

  Future<void> downloadFlow({Set<int>? only}) async {
    final pref = await askPref(context);
    if (pref == null || !mounted) return;
    final List<Video> list;
    if (only != null) {
      final ids = only.toList()..sort();
      list = [for (final i in ids) vids[i]];
    } else {
      list = await all();
    }
    final n = DM.i.addVideos(list, pref);
    toast(tr('added_n').replaceAll('%n', '$n'));
    if (mounted) {
      setState(() {
        selecting = false;
        sel.clear();
      });
    }
  }

  void toggleSel(int i) {
    setState(() {
      if (!sel.add(i)) sel.remove(i);
      if (sel.isEmpty) selecting = false;
    });
  }

  Widget header() => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Thumb(widget.thumb, w: 84, h: 84, radius: widget.channel ? 42 : 14),
          const SizedBox(width: 14),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(widget.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
              const SizedBox(height: 4),
              Text('${vids.length}${done ? '' : '+'} ${tr('videos_n')}', style: const TextStyle(color: Colors.grey)),
            ]),
          ),
        ]),
        const SizedBox(height: 14),
        Row(children: [
          Expanded(
            child: FilledButton.icon(
              style: FilledButton.styleFrom(backgroundColor: kRed, minimumSize: const Size.fromHeight(46)),
              icon: const Icon(Icons.play_arrow_rounded),
              label: Text(tr('play_all')),
              onPressed: vids.isEmpty ? null : () => play(0),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: OutlinedButton.icon(
              style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(46)),
              icon: const Icon(Icons.download_rounded),
              label: Text(tr('download_all')),
              onPressed: vids.isEmpty || fetchingAll ? null : () => downloadFlow(),
            ),
          ),
        ]),
        if (fetchingAll)
          Padding(
            padding: const EdgeInsets.only(top: 12),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(tr('fetching'), style: const TextStyle(color: Colors.grey, fontSize: 12.5)),
              const SizedBox(height: 6),
              const LinearProgressIndicator(),
            ]),
          ),
        const SizedBox(height: 12),
      ]);

  Widget row(int i) {
    final v = vids[i];
    final picked = sel.contains(i);
    return ListTile(
      contentPadding: EdgeInsets.zero,
      selected: picked,
      selectedTileColor: kRed.withValues(alpha: .12),
      leading: Stack(children: [
        Thumb(v.thumbnails.mediumResUrl, w: 112, h: 63, radius: 8),
        PositionedDirectional(
          bottom: 3,
          end: 3,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
            decoration: BoxDecoration(color: Colors.black87, borderRadius: BorderRadius.circular(4)),
            child: Text(dur(v.duration), style: const TextStyle(fontSize: 10)),
          ),
        ),
      ]),
      title: Text(v.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 13.5)),
      subtitle: Text(v.author, style: const TextStyle(fontSize: 11.5)),
      trailing: selecting
          ? Checkbox(value: picked, activeColor: kRed, onChanged: (_) => toggleSel(i))
          : IconButton(icon: const Icon(Icons.download_rounded), onPressed: () => quickDownload(context, v)),
      onTap: () => selecting ? toggleSel(i) : play(i),
      onLongPress: () {
        setState(() => selecting = true);
        if (!picked) toggleSel(i);
      },
    );
  }

  Widget? bottomBar() {
    if (!selecting) return null;
    return SafeArea(
      child: Container(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
        color: kCard,
        child: Row(children: [
          Expanded(child: Text(tr('selected_n').replaceAll('%n', '${sel.length}'), style: const TextStyle(fontWeight: FontWeight.w700))),
          TextButton(
            onPressed: () => setState(() => sel.addAll(List<int>.generate(vids.length, (i) => i))),
            child: Text(tr('select_all')),
          ),
          const SizedBox(width: 6),
          FilledButton.icon(
            style: FilledButton.styleFrom(backgroundColor: kRed),
            icon: const Icon(Icons.download_rounded),
            label: Text(tr('download')),
            onPressed: sel.isEmpty ? null : () => downloadFlow(only: Set<int>.of(sel)),
          ),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          title: Text(selecting ? tr('select') : widget.title, maxLines: 1, overflow: TextOverflow.ellipsis),
          actions: [
            if (vids.isNotEmpty)
              IconButton(
                tooltip: tr('select'),
                icon: Icon(selecting ? Icons.close_rounded : Icons.checklist_rounded),
                onPressed: () => setState(() {
                  selecting = !selecting;
                  sel.clear();
                }),
              ),
          ],
        ),
        bottomNavigationBar: bottomBar(),
        body: loading
            ? const Center(child: CircularProgressIndicator())
            : error != null
                ? ErrorState(error!, reload)
                : ListView.builder(
                    controller: scroll,
                    padding: const EdgeInsets.all(12),
                    itemCount: vids.length + 2,
                    itemBuilder: (_, i) {
                      if (i == 0) return header();
                      if (i <= vids.length) return row(i - 1);
                      return more
                          ? const Padding(padding: EdgeInsets.all(16), child: Center(child: CircularProgressIndicator()))
                          : const SizedBox(height: 24);
                    },
                  ),
      );
}
