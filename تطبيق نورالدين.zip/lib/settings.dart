import 'package:flutter/material.dart';
import 'core.dart';
import 'engine.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});
  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  void pick(String title, Map<String, String> opts, String cur, Future<void> Function(String) save) {
    showModalBottomSheet(
      context: context,
      backgroundColor: kCard,
      shape: kSheetShape,
      builder: (c) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Text(title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
          ),
          for (final e in opts.entries)
            ListTile(
              title: Text(e.value),
              trailing: e.key == cur ? const Icon(Icons.check_rounded, color: kRed) : null,
              onTap: () async {
                await save(e.key);
                if (c.mounted) Navigator.pop(c);
                if (mounted) setState(() {});
              },
            ),
          const SizedBox(height: 8),
        ]),
      ),
    );
  }

  Widget head(String t) => Padding(
        padding: const EdgeInsets.fromLTRB(4, 18, 4, 6),
        child: Text(t, style: const TextStyle(fontWeight: FontWeight.w800, color: kRed)),
      );

  @override
  Widget build(BuildContext context) => ValueListenableBuilder<String>(
        valueListenable: lang,
        builder: (c, l, _) {
          final sqNames = {'auto': tr('sq_auto'), 'low': tr('sq_low'), 'high': tr('sq_high')};
          final dqKeys = ['ask', 'best', '1080', '720', '480', '360', 'audio', 'mp3'];
          return Scaffold(
            appBar: AppBar(title: Text(tr('settings'))),
            body: ListView(padding: const EdgeInsets.all(16), children: [
              head(tr('language')),
              SegmentedButton<String>(
                segments: const [
                  ButtonSegment(value: 'ar', label: Text('العربية')),
                  ButtonSegment(value: 'en', label: Text('English')),
                ],
                selected: {l},
                onSelectionChanged: (s) => Prefs.setLang(s.first),
              ),
              head(tr('watch')),
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.high_quality_rounded),
                title: Text(tr('stream_q')),
                subtitle: Text('${sqNames[Prefs.sq]}\n${tr('sq_hint')}'),
                isThreeLine: true,
                onTap: () => pick(tr('stream_q'), sqNames, Prefs.sq, Prefs.setSq),
              ),
              head(tr('downloads_sec')),
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.download_done_rounded),
                title: Text(tr('default_dl')),
                subtitle: Text(prefLabel(Prefs.dq)),
                onTap: () => pick(tr('default_dl'), {for (final k in dqKeys) k: prefLabel(k)}, Prefs.dq, Prefs.setDq),
              ),
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.stacked_line_chart_rounded),
                title: Text('${tr('parallel')}:  ${Prefs.parallel}'),
                subtitle: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Slider(
                    min: 1,
                    max: 10,
                    divisions: 9,
                    value: Prefs.parallel.toDouble(),
                    label: '${Prefs.parallel}',
                    activeColor: kRed,
                    onChanged: (v) async {
                      await Prefs.setParallel(v.round());
                      DM.i.kick();
                      setState(() {});
                    },
                  ),
                  Text(tr('parallel_hint'), style: const TextStyle(fontSize: 12, color: Colors.grey)),
                ]),
              ),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                secondary: const Icon(Icons.photo_library_rounded),
                title: Text(tr('gallery')),
                value: Prefs.gallery,
                activeColor: kRed,
                onChanged: (v) async {
                  await Prefs.setGallery(v);
                  setState(() {});
                },
              ),
              head(tr('general')),
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.history_rounded),
                title: Text(tr('clear_history')),
                onTap: () async {
                  await Prefs.clearHistory();
                  toast(tr('history_cleared'));
                },
              ),
              const Divider(),
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.info_outline_rounded),
                title: const Text('Nooruddin Top'),
                subtitle: Text('${tr('version')} 2.2.0'),
              ),
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(color: kCard, borderRadius: BorderRadius.circular(14)),
                child: Text(tr('disclaimer'), style: const TextStyle(height: 1.5, color: Colors.white70)),
              ),
            ]),
          );
        },
      );
}
